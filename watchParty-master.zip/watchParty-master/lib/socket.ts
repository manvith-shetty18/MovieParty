import { Server as NetServer } from 'http';
import { Server as SocketIOServer } from 'socket.io';
import { supabase } from './supabase';

export type SocketServer = SocketIOServer;

interface PlaybackState {
    action: 'play' | 'pause' | 'seek';
    currentTime: number;
    timestamp: number;
}

interface UserPresence {
    userId: string;
    username: string;
    avatar?: string;
}

export function initSocketServer(server: NetServer): SocketIOServer {
    const io = new SocketIOServer(server, {
        cors: {
            origin: '*',
            methods: ['GET', 'POST'],
            credentials: true
        },
        allowEIO3: true,
        transports: ['polling', 'websocket']
    });

    // Track users in rooms
    const roomUsers = new Map<string, Set<string>>();
    // Track room permissions (guestControls: true by default)
    const roomPermissions = new Map<string, { guestControls: boolean }>();
    // Track room hosts (roomCode -> socketId)
    const roomHostsMap = new Map<string, string>();
    // Store room host URLs (roomCode -> hostUrl)
    const roomHostUrls = new Map<string, string>();
    // Track locked rooms
    const roomLocked = new Map<string, boolean>();

    io.on('connection', (socket) => {
        console.log('Client connected:', socket.id);

        // Join a room
        socket.on('join-room', async ({ roomCode, userId, username, avatar }) => {
            if (roomLocked.get(roomCode)) {
                socket.emit('error', { message: 'Room is locked by host' });
                return;
            }

            try {
                // Get room with members
                const { data: room, error: roomError } = await supabase
                    .from('rooms')
                    .select(`
            *,
            room_members (
              *,
              users (*)
            )
          `)
                    .eq('code', roomCode)
                    .single();

                if (roomError || !room) {
                    socket.emit('error', { message: 'Room not found' });
                    return;
                }

                socket.join(roomCode);

                // Track user in room
                if (!roomUsers.has(roomCode)) {
                    roomUsers.set(roomCode, new Set());
                }
                roomUsers.get(roomCode)!.add(socket.id);

                // Emit user list to room
                const users = (room.room_members as any[]).map((m: any) => ({
                    userId: m.users.id,
                    username: m.users.username,
                    avatar: m.users.avatar,
                    isHost: m.is_host,
                }));

                socket.emit('joined-room', { room, users });
                socket.to(roomCode).emit('user-joined', {
                    userId,
                    username,
                    avatar,
                });

                console.log(`User ${username} joined room ${roomCode}`);
            } catch (error) {
                console.error('Error joining room:', error);
                socket.emit('error', { message: 'Failed to join room' });
            }
        });

        // Extension join (for browser extension sync)
        socket.on('extension-join', ({ roomCode, username, isHost, hostUrl }) => {
            if (roomLocked.get(roomCode) && !isHost) {
                socket.emit('error', { message: 'Room is locked by host' });
                return;
            }

            socket.join(roomCode);
            (socket as any).username = username || 'User'; // Store username on socket

            if (!roomUsers.has(roomCode)) {
                roomUsers.set(roomCode, new Set());
            }
            roomUsers.get(roomCode)!.add(socket.id);

            // If host, register as host
            if (isHost) {
                roomHostsMap.set(roomCode, socket.id);
                roomHostUrls.set(roomCode, hostUrl);
                console.log(`Host registered for ${roomCode}: ${username} (${socket.id})`);
            }

            // Get list of current users in room
            const currentUsers: any[] = [];
            const roomSockets = io.sockets.adapter.rooms.get(roomCode);
            if (roomSockets) {
                roomSockets.forEach(socketId => {
                    const s = io.sockets.sockets.get(socketId);
                    if (s && (s as any).username) {
                        currentUsers.push({
                            username: (s as any).username,
                            isHost: roomHostsMap.get(roomCode) === socketId
                        });
                    }
                });
            }
            // Send user list and permissions to self
            socket.emit('room-users', currentUsers);

            // Send permissions
            if (!roomPermissions.has(roomCode)) {
                roomPermissions.set(roomCode, { guestControls: true });
            }
            socket.emit('permissions-updated', roomPermissions.get(roomCode));

            // If guest, send them the host URL so they can redirect
            if (!isHost && roomHostUrls.has(roomCode)) {
                socket.emit('room-info', {
                    hostUrl: roomHostUrls.get(roomCode)
                });
            }

            // Notify others in room
            socket.to(roomCode).emit('user-joined-ext', { username: username || 'User' });
            console.log(`Extension ${username || socket.id} joined room ${roomCode} (host: ${isHost})`);
        });

        // Extension chat message
        socket.on('chat-message', ({ roomCode, username, message, timestamp }) => {
            // Broadcast to everyone in room
            io.to(roomCode).emit('chat-message', { username, message, timestamp });
            console.log(`Chat in ${roomCode}: ${username}: ${message}`);
        });

        // Reaction (emoji)
        socket.on('reaction', ({ roomCode, username, emoji }) => {
            // Check if room exists
            const roomSize = io.sockets.adapter.rooms.get(roomCode)?.size || 0;
            console.log(`Reaction in ${roomCode} (size: ${roomSize}): ${username} sent ${emoji}`);

            // Broadcast to others (using socket.to so sender doesn't get double)
            socket.to(roomCode).emit('reaction', { username, emoji });
        });

        // Voice chat signaling
        socket.on('voice-join', ({ roomCode, username }) => {
            socket.to(roomCode).emit('voice-user-joined', {
                socketId: socket.id,
                username
            });
            console.log(`Voice: ${username} joined in ${roomCode}`);
        });

        socket.on('voice-leave', ({ roomCode, username }) => {
            socket.to(roomCode).emit('voice-user-left', {
                socketId: socket.id,
                username
            });
            console.log(`Voice: ${username} left in ${roomCode}`);
        });

        socket.on('voice-offer', ({ roomCode, to, offer, from, username }) => {
            io.to(to).emit('voice-offer', { offer, from, username });
        });

        socket.on('voice-answer', ({ roomCode, to, answer, from }) => {
            io.to(to).emit('voice-answer', { answer, from });
        });

        socket.on('voice-ice-candidate', ({ roomCode, to, candidate }) => {
            io.to(to).emit('voice-ice-candidate', { candidate, from: socket.id });
        });

        socket.on('voice-mute', ({ roomCode, username, muted }) => {
            socket.to(roomCode).emit('voice-mute', { username, muted });
        });

        // Update permissions (Host only)
        socket.on('update-permissions', ({ roomCode, guestControls }) => {
            roomPermissions.set(roomCode, { guestControls });
            io.to(roomCode).emit('permissions-updated', { guestControls });
            console.log(`Permissions updated in ${roomCode}: guestControls=${guestControls}`);
        });

        // Kick User (Host only)
        socket.on('kick-user', ({ roomCode, targetUsername }) => {
            console.log(`Kick request in ${roomCode} for ${targetUsername}`);

            // Find socket for user
            const roomSockets = io.sockets.adapter.rooms.get(roomCode);
            if (roomSockets) {
                roomSockets.forEach(socketId => {
                    const s = io.sockets.sockets.get(socketId);
                    if (s && (s as any).username === targetUsername) {
                        // Notify user they are kicked
                        s.emit('kicked');
                        // Make them leave the room
                        s.leave(roomCode);
                        // Notify others
                        io.to(roomCode).emit('user-kicked', { username: targetUsername });

                        // Clean up tracking
                        if (roomUsers.has(roomCode)) {
                            roomUsers.get(roomCode)!.delete(socketId);
                        }
                    }
                });
            }
        });

        // Lock Room (Host only)
        socket.on('lock-room', ({ roomCode, locked }) => {
            roomLocked.set(roomCode, locked);
            io.to(roomCode).emit('room-locked', { locked });
            console.log(`Room ${roomCode} locked status: ${locked}`);
        });

        // Leave room
        socket.on('leave-room', ({ roomCode, userId, username }) => {
            socket.leave(roomCode);

            if (roomUsers.has(roomCode)) {
                roomUsers.get(roomCode)!.delete(socket.id);
            }

            socket.to(roomCode).emit('user-left', { userId, username });
            console.log(`User ${username} left room ${roomCode}`);
        });

        // Playback synchronization
        socket.on('playback-update', ({ roomCode, action, currentTime, userId }) => {
            const timestamp = Date.now();
            const playbackState: PlaybackState = {
                action,
                currentTime,
                timestamp,
            };

            // Broadcast to all other users in the room
            socket.to(roomCode).emit('sync-playback', {
                ...playbackState,
                userId,
            });

            console.log(`Playback update in room ${roomCode}:`, action, currentTime);
        });

        // Chat messages
        socket.on('send-message', async ({ roomCode, userId, content }) => {
            try {
                // Get room id from code
                const { data: room } = await supabase
                    .from('rooms')
                    .select('id')
                    .eq('code', roomCode)
                    .single();

                if (!room) return;

                // Insert message
                const { data: message, error } = await supabase
                    .from('messages')
                    .insert({
                        room_id: room.id,
                        user_id: userId,
                        content,
                    })
                    .select(`
            *,
            users (username, avatar)
          `)
                    .single();

                if (error) throw error;

                io.to(roomCode).emit('new-message', {
                    id: message.id,
                    content: message.content,
                    username: (message.users as any).username,
                    avatar: (message.users as any).avatar,
                    timestamp: message.timestamp,
                });
            } catch (error) {
                console.error('Error sending message:', error);
            }
        });

        // Typing indicator
        socket.on('typing', ({ roomCode, username, isTyping }) => {
            if (isTyping !== undefined) {
                // Web app format
                socket.to(roomCode).emit('user-typing', { username, isTyping });
            } else {
                // Extension format
                socket.to(roomCode).emit('typing', { username });
            }
        });

        // Disconnect
        socket.on('disconnect', () => {
            console.log('Client disconnected:', socket.id);

            // Clean up user from all rooms
            roomUsers.forEach((users, roomCode) => {
                if (users.has(socket.id)) {
                    users.delete(socket.id);
                    socket.to(roomCode).emit('user-disconnected', { socketId: socket.id });
                }
            });
        });
    });

    return io;
}
