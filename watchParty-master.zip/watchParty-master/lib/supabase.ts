import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface Room {
    id: string;
    code: string;
    name: string;
    platform: string;
    video_url: string | null;
    host_id: string;
    is_active: boolean;
    created_at: string;
    updated_at: string;
}

export interface User {
    id: string;
    username: string;
    avatar: string | null;
    created_at: string;
}

export interface RoomMember {
    id: string;
    room_id: string;
    user_id: string;
    is_host: boolean;
    joined_at: string;
}

export interface Message {
    id: string;
    room_id: string;
    user_id: string;
    content: string;
    timestamp: string;
}
