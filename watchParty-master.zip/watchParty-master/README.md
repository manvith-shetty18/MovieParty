# WatchParty - Synchronized Watch Party Platform

A modern, real-time synchronized watch party platform built with Next.js, Socket.io, and Supabase. Watch Netflix, YouTube, Prime Video, and more together with perfect synchronization, real-time chat, and user presence indicators.

## ✨ Features

- 🎬 **Real-time Synchronization**: Perfect sync of play, pause, and seek across all viewers
- 💬 **Live Chat**: Real-time messaging with typing indicators
- 👥 **User Presence**: See who's watching with you
- 🌐 **Multi-Platform Support**: YouTube (embedded), Netflix & Prime Video (via extension)
- 🎨 **Modern UI**: Beautiful glassmorphism design with smooth animations
- 🔒 **Secure**: Supabase Row Level Security (RLS) enabled

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ installed
- A Supabase account ([create one free](https://supabase.com))

### 1. Clone & Install

```bash
cd watchParty
npm install
```

### 2. Set Up Supabase

1. Go to [https://supabase.com](https://supabase.com) and create a new project
2. Wait for the database to initialize
3. Go to **SQL Editor** in your Supabase dashboard
4. Copy the contents of `supabase/schema.sql` and run it in the SQL editor
5. This will create all necessary tables and policies

### 3. Configure Environment Variables

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

Edit `.env` and add your Supabase credentials:

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-here
NEXT_PUBLIC_APP_URL=http://localhost:3000
NEXT_PUBLIC_SOCKET_URL=http://localhost:3000
```

**Where to find your Supabase credentials:**
- Go to your Supabase project dashboard
- Navigate to **Settings** > **API**
- Copy the **Project URL** for `NEXT_PUBLIC_SUPABASE_URL`
- Copy the **anon/public** key for `NEXT_PUBLIC_SUPABASE_ANON_KEY`

### 4. Start the Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser!

## 📖 How to Use

### Creating a Watch Party

1. Click "Create Room" on the homepage
2. Enter your name and room details
3. Select a platform (YouTube, Netflix, Prime Video, or Custom URL)
4. For YouTube: Paste a YouTube URL (or set it later)
5. Share the room code with friends!

### Joining a Watch Party

1. Click "Join Room" on the homepage
2. Enter your name
3. Enter the 8-character room code
4. Start watching together!

### Platform Support

- **YouTube**: Full embedded player support with sync controls
- **Custom Video URLs**: Direct .mp4, .webm video file support
- **Netflix/Prime Video**: Coming soon via browser extension

## 🏗️ Tech Stack

- **Frontend**: Next.js 14, React, TypeScript
- **Styling**: Tailwind CSS with custom theme
- **Animations**: Framer Motion
- **Real-time**: Socket.io for WebSocket connections
- **Database**: Supabase (PostgreSQL)
- **UI Components**: Radix UI primitives

## 📁 Project Structure

```
watchParty/
├── app/                    # Next.js app directory
│   ├── api/               # API routes
│   │   └── rooms/         # Room management endpoints
│   ├── room/[code]/       # Room page
│   ├── layout.tsx         # Root layout
│   ├── page.tsx           # Landing page
│   └── globals.css        # Global styles
├── components/            # React components
│   ├── ChatPanel.tsx      # Real-time chat
│   ├── CreateRoomDialog.tsx
│   ├── JoinRoomDialog.tsx
│   ├── UserList.tsx       # Connected users
│   └── VideoPlayer.tsx    # Synced video player
├── hooks/                 # Custom React hooks
│   ├── useSocket.ts       # Socket.io connection
│   └── useRoomSync.ts     # Room synchronization
├── lib/                   # Utilities
│   ├── socket.ts          # Socket.io server
│   └── supabase.ts        # Supabase client
├── supabase/              # Database schema
│   └── schema.sql         # SQL schema
└── server.js              # Custom Next.js + Socket.io server
```

## 🎨 Design Features

- **Glassmorphism**: Beautiful frosted glass effects
- **Gradient Text**: Eye-catching color gradients
- **Smooth Animations**: Framer Motion powered transitions
- **Dark Theme**: Easy on the eyes
- **Responsive**: Works on desktop and mobile

## 🔐 Security

- Row Level Security (RLS) enabled on all tables
- Supabase handles authentication and authorization
- WebSocket connections are CORS-protected
- No sensitive data exposed to client

## 🛠️ Development

```bash
# Development mode
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Lint code
npm run lint
```

## 🐛 Troubleshooting

### "Room not found" error
- Ensure Supabase credentials are correct in `.env`
- Check that you've run the SQL schema in Supabase

### Socket.io not connecting
- Verify `NEXT_PUBLIC_SOCKET_URL` matches your server URL
- Check firewall settings

### Videos not playing
- For YouTube: Ensure the video is embeddable
- For custom URLs: File must be served with proper CORS headers

## 📝 Database Schema

The platform uses 4 main tables:

- **users**: User profiles (id, username, avatar)
- **rooms**: Watch party rooms (code, name, platform, video_url)
- **room_members**: User-room relationships (room_id, user_id, is_host)
- **messages**: Chat messages (room_id, user_id, content, timestamp)

Full schema available in `supabase/schema.sql`

## 🚧 Roadmap

- [ ] Browser extension for Netflix/Prime Video sync
- [ ] Video quality settings
- [ ] User authentication
- [ ] Room privacy controls
- [ ] Reactions and emojis
- [ ] Watch history
- [ ] Mobile app

## 📄 License

MIT License - feel free to use this project for your own purposes!

## 🤝 Contributing

Contributions are welcome! Feel free to open issues or submit pull requests.

---

**Built with ❤️ using Next.js, Socket.io, and Supabase**
