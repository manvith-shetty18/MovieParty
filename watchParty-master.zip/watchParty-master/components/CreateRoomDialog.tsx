'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { nanoid } from 'nanoid';

interface CreateRoomDialogProps {
    onClose: () => void;
}

export function CreateRoomDialog({ onClose }: CreateRoomDialogProps) {
    const router = useRouter();
    const [roomName, setRoomName] = useState('');
    const [platform, setPlatform] = useState('youtube');
    const [videoUrl, setVideoUrl] = useState('');
    const [username, setUsername] = useState('');
    const [isCreating, setIsCreating] = useState(false);

    useEffect(() => {
        // Load user from localStorage
        const storedUser = localStorage.getItem('watch-party-user');
        if (storedUser) {
            const user = JSON.parse(storedUser);
            setUsername(user.username || '');
        }
    }, []);

    const handleCreate = async () => {
        if (!roomName || !username) {
            alert('Please fill in all required fields');
            return;
        }

        setIsCreating(true);

        try {
            // Create or update user in localStorage
            const userId = nanoid();
            const user = {
                id: userId,
                username,
                avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${userId}`,
            };
            localStorage.setItem('watch-party-user', JSON.stringify(user));

            // Create room via API
            const response = await fetch('/api/rooms', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: roomName,
                    platform,
                    videoUrl: videoUrl || null,
                    hostId: user.id,
                    hostUsername: user.username,
                    hostAvatar: user.avatar,
                }),
            });

            if (!response.ok) {
                throw new Error('Failed to create room');
            }

            const room = await response.json();

            // Navigate to room
            router.push(`/room/${room.code}`);
        } catch (error) {
            console.error('Error creating room:', error);
            alert('Failed to create room. Please try again.');
            setIsCreating(false);
        }
    };

    return (
        <AnimatePresence>
            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={onClose}
                className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            >
                <motion.div
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.9, opacity: 0 }}
                    onClick={(e) => e.stopPropagation()}
                    className="glass rounded-3xl p-8 max-w-md w-full shadow-2xl"
                >
                    <h2 className="text-3xl font-bold mb-6 gradient-text">Create Watch Party</h2>

                    <div className="space-y-4">
                        {/* Username */}
                        <div>
                            <label className="block text-sm font-medium mb-2 text-text-muted">
                                Your Name *
                            </label>
                            <input
                                type="text"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                placeholder="Enter your name"
                                className="input"
                                maxLength={20}
                            />
                        </div>

                        {/* Room Name */}
                        <div>
                            <label className="block text-sm font-medium mb-2 text-text-muted">
                                Room Name *
                            </label>
                            <input
                                type="text"
                                value={roomName}
                                onChange={(e) => setRoomName(e.target.value)}
                                placeholder="My Watch Party"
                                className="input"
                                maxLength={50}
                            />
                        </div>

                        {/* Platform */}
                        <div>
                            <label className="block text-sm font-medium mb-2 text-text-muted">
                                Platform
                            </label>
                            <select
                                value={platform}
                                onChange={(e) => setPlatform(e.target.value)}
                                className="input"
                            >
                                <option value="youtube">YouTube</option>
                                <option value="netflix">Netflix (requires extension)</option>
                                <option value="prime">Prime Video (requires extension)</option>
                                <option value="custom">Custom URL</option>
                            </select>
                        </div>

                        {/* Video URL */}
                        {platform === 'youtube' || platform === 'custom' ? (
                            <div>
                                <label className="block text-sm font-medium mb-2 text-text-muted">
                                    Video URL {platform === 'youtube' ? '(optional)' : ''}
                                </label>
                                <input
                                    type="url"
                                    value={videoUrl}
                                    onChange={(e) => setVideoUrl(e.target.value)}
                                    placeholder="https://youtube.com/watch?v=..."
                                    className="input"
                                />
                            </div>
                        ) : null}

                        {platform !== 'youtube' && platform !== 'custom' && (
                            <div className="bg-accent/20 border border-accent/30 rounded-lg p-3">
                                <p className="text-sm text-text-muted">
                                    ℹ️ Browser extension required for {platform}. You can set the video from within the room.
                                </p>
                            </div>
                        )}
                    </div>

                    <div className="flex gap-3 mt-8">
                        <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={handleCreate}
                            disabled={isCreating}
                            className="btn btn-primary flex-1"
                        >
                            {isCreating ? 'Creating...' : 'Create Room 🚀'}
                        </motion.button>
                        <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={onClose}
                            className="btn btn-secondary px-6"
                            disabled={isCreating}
                        >
                            Cancel
                        </motion.button>
                    </div>
                </motion.div>
            </motion.div>
        </AnimatePresence>
    );
}
