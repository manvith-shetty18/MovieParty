'use client';

import { useState, useEffect, useRef } from 'react';
import { Socket } from 'socket.io-client';
import { motion, AnimatePresence } from 'framer-motion';

interface Message {
    id: string;
    content: string;
    username: string;
    avatar?: string;
    timestamp: Date;
}

interface ChatPanelProps {
    socket: Socket | null;
    roomCode: string;
    user: any;
    messages: Message[];
}

export function ChatPanel({ socket, roomCode, user, messages: initialMessages }: ChatPanelProps) {
    const [messages, setMessages] = useState<Message[]>(initialMessages);
    const [newMessage, setNewMessage] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const [typingUsers, setTypingUsers] = useState<string[]>([]);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

    useEffect(() => {
        if (!socket) return;

        socket.on('new-message', (message: Message) => {
            setMessages((prev) => [...prev, message]);
        });

        socket.on('user-typing', ({ username, isTyping: typing }: any) => {
            if (typing) {
                setTypingUsers((prev) => [...new Set([...prev, username])]);
            } else {
                setTypingUsers((prev) => prev.filter((u) => u !== username));
            }
        });

        return () => {
            socket.off('new-message');
            socket.off('user-typing');
        };
    }, [socket]);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleTyping = (e: React.ChangeEvent<HTMLInputElement>) => {
        setNewMessage(e.target.value);

        if (!socket || !user) return;

        if (!isTyping) {
            setIsTyping(true);
            socket.emit('typing', { roomCode, username: user.username, isTyping: true });
        }

        if (typingTimeoutRef.current) {
            clearTimeout(typingTimeoutRef.current);
        }

        typingTimeoutRef.current = setTimeout(() => {
            setIsTyping(false);
            socket?.emit('typing', { roomCode, username: user.username, isTyping: false });
        }, 1000);
    };

    const handleSend = (e: React.FormEvent) => {
        e.preventDefault();

        if (!newMessage.trim() || !socket || !user) return;

        socket.emit('send-message', {
            roomCode,
            userId: user.id,
            content: newMessage.trim(),
        });

        setNewMessage('');
        setIsTyping(false);
        socket.emit('typing', { roomCode, username: user.username, isTyping: false });
    };

    return (
        <div className="flex flex-col h-full">
            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
                <AnimatePresence>
                    {messages.map((message) => (
                        <motion.div
                            key={message.id}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0 }}
                            className="flex gap-3"
                        >
                            <img
                                src={message.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${message.username}`}
                                alt={message.username}
                                className="w-8 h-8 rounded-full flex-shrink-0"
                            />
                            <div className="flex-1 min-w-0">
                                <div className="flex items-baseline gap-2 mb-1">
                                    <span className="font-semibold text-sm">{message.username}</span>
                                    <span className="text-xs text-text-muted">
                                        {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                    </span>
                                </div>
                                <p className="text-sm break-words">{message.content}</p>
                            </div>
                        </motion.div>
                    ))}
                </AnimatePresence>

                {typingUsers.length > 0 && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="text-sm text-text-muted italic"
                    >
                        {typingUsers.join(', ')} {typingUsers.length === 1 ? 'is' : 'are'} typing...
                    </motion.div>
                )}

                <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <form onSubmit={handleSend} className="p-4 border-t border-surface-hover">
                <div className="flex gap-2">
                    <input
                        type="text"
                        value={newMessage}
                        onChange={handleTyping}
                        placeholder="Type a message..."
                        className="input flex-1"
                        maxLength={500}
                    />
                    <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        type="submit"
                        disabled={!newMessage.trim()}
                        className="btn btn-primary px-6"
                    >
                        Send
                    </motion.button>
                </div>
            </form>
        </div>
    );
}
