'use client';

import { motion } from 'framer-motion';

interface User {
    userId: string;
    username: string;
    avatar?: string;
    isHost?: boolean;
}

interface UserListProps {
    users: User[];
    hostId: string;
    currentUserId: string;
}

export function UserList({ users, hostId, currentUserId }: UserListProps) {
    return (
        <div className="p-4 space-y-2 overflow-y-auto">
            {users.length === 0 ? (
                <div className="text-center py-8 text-text-muted">
                    <p>No users yet</p>
                    <p className="text-sm">Share the room code to invite friends!</p>
                </div>
            ) : (
                users.map((user, index) => (
                    <motion.div
                        key={user.userId}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                        className="glass rounded-xl p-3 flex items-center gap-3"
                    >
                        <div className="relative">
                            <img
                                src={user.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.userId}`}
                                alt={user.username}
                                className="w-10 h-10 rounded-full"
                            />
                            <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-surface rounded-full" />
                        </div>

                        <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                                <span className="font-semibold truncate">{user.username}</span>
                                {user.userId === currentUserId && (
                                    <span className="text-xs bg-accent/20 text-accent px-2 py-0.5 rounded">
                                        You
                                    </span>
                                )}
                            </div>
                            {user.userId === hostId && (
                                <div className="flex items-center gap-1 text-xs text-text-muted">
                                    <span>👑</span>
                                    <span>Host</span>
                                </div>
                            )}
                        </div>
                    </motion.div>
                ))
            )}

            <div className="pt-4 border-t border-surface-hover mt-4">
                <div className="text-sm text-text-muted text-center">
                    {users.length} {users.length === 1 ? 'person' : 'people'} watching
                </div>
            </div>
        </div>
    );
}
