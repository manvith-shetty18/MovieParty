'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { nanoid } from 'nanoid';

interface JoinRoomDialogProps {
    onClose: () => void;
}

export function JoinRoomDialog({ onClose }: JoinRoomDialogProps) {
    const router = useRouter();
    const [roomCode, setRoomCode] = useState('');
    const [username, setUsername] = useState('');
    const [isJoining, setIsJoining] = useState(false);

    useEffect(() => {
        const storedUser = localStorage.getItem('watch-party-user');
        if (storedUser) {
            const user = JSON.parse(storedUser);
            setUsername(user.username || '');
        }
    }, []);

    const handleJoin = async () => {
        if (!roomCode || !username) {
            alert('Please fill in all fields');
            return;
        }

        setIsJoining(true);

        try {
            // Check if room exists
            const checkResponse = await fetch(`/api/rooms/${roomCode}`);
            if (!checkResponse.ok) {
                throw new Error('Room not found');
            }

            // Create or update user in localStorage
            const userId = nanoid();
            const user = {
                id: userId,
                username,
                avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${userId}`,
            };
            localStorage.setItem('watch-party-user', JSON.stringify(user));

            // Join room via API
            const joinResponse = await fetch(`/api/rooms/${roomCode}/join`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    userId: user.id,
                    username: user.username,
                    avatar: user.avatar,
                }),
            });

            if (!joinResponse.ok) {
                throw new Error('Failed to join room');
            }

            // Navigate to room
            router.push(`/room/${roomCode}`);
        } catch (error) {
            console.error('Error joining room:', error);
            alert('Failed to join room. Please check the room code and try again.');
            setIsJoining(false);
        }
    };

    return (
        <AnimatePresence>
            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={onClose}
                className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            >
                <motion.div
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.9, opacity: 0 }}
                    onClick={(e) => e.stopPropagation()}
                    className="glass rounded-3xl p-8 max-w-md w-full shadow-2xl"
                >
                    <h2 className="text-3xl font-bold mb-6 gradient-text">Join Watch Party</h2>

                    <div className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium mb-2 text-text-muted">
                                Your Name *
                            </label>
                            <input
                                type="text"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                placeholder="Enter your name"
                                className="input"
                                maxLength={20}
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-medium mb-2 text-text-muted">
                                Room Code *
                            </label>
                            <input
                                type="text"
                                value={roomCode}
                                onChange={(e) => setRoomCode(e.target.value)}
                                placeholder="Enter room code"
                                className="input text-2xl tracking-wider font-mono text-center"
                                maxLength={8}
                            />
                            <p className="text-xs text-text-muted mt-2">
                                Enter the 8-character code shared by the room host
                            </p>
                        </div>
                    </div>

                    <div className="flex gap-3 mt-8">
                        <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={handleJoin}
                            disabled={isJoining}
                            className="btn btn-primary flex-1"
                        >
                            {isJoining ? 'Joining...' : 'Join Room 🎉'}
                        </motion.button>
                        <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={onClose}
                            className="btn btn-secondary px-6"
                            disabled={isJoining}
                        >
                            Cancel
                        </motion.button>
                    </div>
                </motion.div>
            </motion.div>
        </AnimatePresence>
    );
}
