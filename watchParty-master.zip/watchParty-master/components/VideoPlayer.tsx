'use client';

import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';

interface VideoPlayerProps {
    room: any;
    playbackState: any;
    onPlaybackUpdate: (action: 'play' | 'pause' | 'seek', currentTime: number) => void;
    isHost: boolean;
}

export function VideoPlayer({ room, playbackState, onPlaybackUpdate, isHost }: VideoPlayerProps) {
    const videoRef = useRef<HTMLVideoElement>(null);
    const iframeRef = useRef<HTMLIFrameElement>(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(0);
    const [videoUrl, setVideoUrl] = useState(room.video_url || '');
    const [tempUrl, setTempUrl] = useState('');
    const [isEditingUrl, setIsEditingUrl] = useState(!room.video_url);

    // Sync playback state from other users
    useEffect(() => {
        if (!playbackState || !videoRef.current) return;

        const video = videoRef.current;
        const timeDiff = Math.abs(video.currentTime - playbackState.currentTime);

        if (playbackState.action === 'play') {
            video.currentTime = playbackState.currentTime;
            video.play().catch(console.error);
            setIsPlaying(true);
        } else if (playbackState.action === 'pause') {
            video.currentTime = playbackState.currentTime;
            video.pause();
            setIsPlaying(false);
        } else if (playbackState.action === 'seek' && timeDiff > 1) {
            video.currentTime = playbackState.currentTime;
        }
    }, [playbackState]);

    const handlePlay = () => {
        if (!videoRef.current) return;
        onPlaybackUpdate('play', videoRef.current.currentTime);
        setIsPlaying(true);
    };

    const handlePause = () => {
        if (!videoRef.current) return;
        onPlaybackUpdate('pause', videoRef.current.currentTime);
        setIsPlaying(false);
    };

    const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (!videoRef.current) return;
        const newTime = parseFloat(e.target.value);
        videoRef.current.currentTime = newTime;
        setCurrentTime(newTime);
        onPlaybackUpdate('seek', newTime);
    };

    const handleTimeUpdate = () => {
        if (!videoRef.current) return;
        setCurrentTime(videoRef.current.currentTime);
        setDuration(videoRef.current.duration);
    };

    const handleSetUrl = () => {
        if (!tempUrl) return;
        setVideoUrl(tempUrl);
        setIsEditingUrl(false);
    };

    const getYouTubeEmbedUrl = (url: string) => {
        try {
            const urlObj = new URL(url);
            let videoId = '';

            if (urlObj.hostname.includes('youtube.com')) {
                videoId = urlObj.searchParams.get('v') || '';
            } else if (urlObj.hostname.includes('youtu.be')) {
                videoId = urlObj.pathname.slice(1);
            }

            return videoId ? `https://www.youtube.com/embed/${videoId}?enablejsapi=1` : null;
        } catch {
            return null;
        }
    };

    const formatTime = (seconds: number) => {
        if (isNaN(seconds)) return '0:00';
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    };

    const isDirectVideoUrl = (url: string) => {
        try {
            const urlObj = new URL(url);
            const path = urlObj.pathname.toLowerCase();
            return path.endsWith('.mp4') || path.endsWith('.webm') || path.endsWith('.ogg');
        } catch {
            return false;
        }
    };

    const youtubeEmbedUrl = room.platform === 'youtube' && videoUrl ? getYouTubeEmbedUrl(videoUrl) : null;
    const isDirectVideo = room.platform === 'custom' && videoUrl && isDirectVideoUrl(videoUrl);
    const shouldEmbedIframe = videoUrl && !youtubeEmbedUrl && !isDirectVideo && room.platform === 'custom';

    return (
        <div className="flex flex-col gap-4 h-full">
            {/* Video Container */}
            <div className="flex-1 glass rounded-2xl overflow-hidden relative flex items-center justify-center bg-black/30">
                {!videoUrl || isEditingUrl ? (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="p-8 text-center max-w-md"
                    >
                        <div className="text-6xl mb-4">🎬</div>
                        <h3 className="text-2xl font-bold mb-4">Set Video URL</h3>
                        <div className="space-y-3">
                            <input
                                type="url"
                                value={tempUrl}
                                onChange={(e) => setTempUrl(e.target.value)}
                                placeholder="https://youtube.com/watch?v=..."
                                className="input"
                            />
                            <button onClick={handleSetUrl} className="btn btn-primary w-full">
                                Load Video
                            </button>
                        </div>
                        {!isHost && (
                            <p className="text-sm text-text-muted mt-4">
                                Waiting for host to set video...
                            </p>
                        )}
                    </motion.div>
                ) : youtubeEmbedUrl ? (
                    <iframe
                        ref={iframeRef}
                        src={youtubeEmbedUrl}
                        className="w-full h-full"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                    />
                ) : shouldEmbedIframe ? (
                    <div className="w-full h-full flex flex-col">
                        <iframe
                            ref={iframeRef}
                            src={videoUrl}
                            className="w-full h-full"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                            allowFullScreen
                            sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
                        />
                        <div className="text-xs text-text-muted p-2 text-center bg-surface/50">
                            Embedded: {new URL(videoUrl).hostname}
                        </div>
                    </div>
                ) : isDirectVideo ? (
                    <video
                        ref={videoRef}
                        src={videoUrl}
                        className="w-full h-full"
                        onPlay={handlePlay}
                        onPause={handlePause}
                        onTimeUpdate={handleTimeUpdate}
                        controls
                    />
                ) : (
                    <div className="text-center p-8">
                        <div className="text-6xl mb-4">🔌</div>
                        <h3 className="text-xl font-bold mb-2">Browser Extension Required</h3>
                        <p className="text-text-muted mb-4">
                            To sync with {room.platform}, please install our browser extension.
                        </p>
                        <p className="text-sm text-text-muted">
                            Extension support coming soon!
                        </p>
                    </div>
                )}
            </div>

            {/* Controls */}
            {videoUrl && !youtubeEmbedUrl && room.platform === 'custom' && (
                <div className="glass rounded-xl p-4">
                    <div className="flex items-center gap-4">
                        <button
                            onClick={isPlaying ? handlePause : handlePlay}
                            className="btn btn-primary px-4 py-2 text-2xl"
                        >
                            {isPlaying ? '⏸' : '▶'}
                        </button>

                        <div className="flex-1 flex items-center gap-2">
                            <span className="text-sm text-text-muted min-w-12">
                                {formatTime(currentTime)}
                            </span>
                            <input
                                type="range"
                                min="0"
                                max={duration || 0}
                                value={currentTime}
                                onChange={handleSeek}
                                className="flex-1"
                            />
                            <span className="text-sm text-text-muted min-w-12">
                                {formatTime(duration)}
                            </span>
                        </div>

                        {isHost && (
                            <button
                                onClick={() => setIsEditingUrl(true)}
                                className="btn btn-secondary px-4 py-2"
                            >
                                Change Video
                            </button>
                        )}
                    </div>
                </div>
            )}

            {(youtubeEmbedUrl || shouldEmbedIframe) && isHost && (
                <div className="glass rounded-xl p-3 flex justify-center">
                    <button
                        onClick={() => setIsEditingUrl(true)}
                        className="btn btn-secondary px-4 py-2"
                    >
                        Change Video
                    </button>
                </div>
            )}
        </div>
    );
}
