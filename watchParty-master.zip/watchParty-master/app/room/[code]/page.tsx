'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useSocket } from '@/hooks/useSocket';
import { useRoomSync } from '@/hooks/useRoomSync';
import { VideoPlayer } from '@/components/VideoPlayer';
import { ChatPanel } from '@/components/ChatPanel';
import { UserList } from '@/components/UserList';
import { motion } from 'framer-motion';

export default function RoomPage() {
    const params = useParams();
    const router = useRouter();
    const roomCode = params.code as string;

    const [room, setRoom] = useState<any>(null);
    const [user, setUser] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const [showChat, setShowChat] = useState(true);
    const [showUsers, setShowUsers] = useState(true);

    const { socket, isConnected } = useSocket();
    const { playbackState, updatePlayback, users } = useRoomSync(
        socket,
        roomCode,
        user?.id || ''
    );

    // Load room data
    useEffect(() => {
        const storedUser = localStorage.getItem('watch-party-user');
        if (!storedUser) {
            router.push('/');
            return;
        }

        setUser(JSON.parse(storedUser));

        // Fetch room details
        fetch(`/api/rooms/${roomCode}`)
            .then((res) => {
                if (!res.ok) throw new Error('Room not found');
                return res.json();
            })
            .then((data) => {
                setRoom(data);
                setLoading(false);
            })
            .catch((error) => {
                console.error('Error fetching room:', error);
                alert('Room not found');
                router.push('/');
            });
    }, [roomCode, router]);

    const copyRoomCode = () => {
        navigator.clipboard.writeText(roomCode);
        alert('Room code copied to clipboard!');
    };

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <div className="text-center">
                    <div className="animate-spin text-6xl mb-4">⏳</div>
                    <p className="text-xl text-text-muted">Loading room...</p>
                </div>
            </div>
        );
    }

    const isHost = room.hostId === user?.id;

    return (
        <div className="min-h-screen flex flex-col">
            {/* Header */}
            <header className="glass border-b border-surface-hover p-4">
                <div className="max-w-7xl mx-auto flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <motion.button
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            onClick={() => router.push('/')}
                            className="text-2xl"
                        >
                            🏠
                        </motion.button>
                        <div>
                            <h1 className="text-xl font-bold">{room.name}</h1>
                            <div className="flex items-center gap-2 text-sm text-text-muted">
                                <span>Room Code:</span>
                                <button
                                    onClick={copyRoomCode}
                                    className="font-mono bg-surface px-2 py-1 rounded hover:bg-surface-hover transition-colors"
                                >
                                    {roomCode}
                                </button>
                                {isHost && <span className="text-accent">👑 Host</span>}
                            </div>
                        </div>
                    </div>

                    <div className="flex items-center gap-2">
                        <span className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
                        <span className="text-sm text-text-muted">
                            {isConnected ? 'Connected' : 'Connecting...'}
                        </span>
                    </div>
                </div>
            </header>

            {/* Main Content */}
            <div className="flex-1 flex overflow-hidden">
                {/* Video Player Area */}
                <div className="flex-1 flex flex-col p-4">
                    <VideoPlayer
                        room={room}
                        playbackState={playbackState}
                        onPlaybackUpdate={updatePlayback}
                        isHost={isHost}
                    />
                </div>

                {/* Sidebar */}
                <div className="w-96 flex flex-col glass border-l border-surface-hover">
                    {/* Tabs */}
                    <div className="flex border-b border-surface-hover">
                        <button
                            onClick={() => { setShowChat(true); setShowUsers(false); }}
                            className={`flex-1 py-3 px-4 font-semibold transition-colors ${showChat ? 'bg-surface text-text' : 'text-text-muted hover:bg-surface/50'
                                }`}
                        >
                            💬 Chat
                        </button>
                        <button
                            onClick={() => { setShowChat(false); setShowUsers(true); }}
                            className={`flex-1 py-3 px-4 font-semibold transition-colors ${showUsers ? 'bg-surface text-text' : 'text-text-muted hover:bg-surface/50'
                                }`}
                        >
                            👥 Users ({users.length})
                        </button>
                    </div>

                    {/* Content */}
                    <div className="flex-1 overflow-hidden">
                        {showChat && (
                            <ChatPanel
                                socket={socket}
                                roomCode={roomCode}
                                user={user}
                                messages={room.messages || []}
                            />
                        )}
                        {showUsers && (
                            <UserList
                                users={users}
                                hostId={room.hostId}
                                currentUserId={user?.id}
                            />
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
