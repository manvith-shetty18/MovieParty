import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';

// GET /api/rooms/[code] - Get room details
export async function GET(
    request: NextRequest,
    { params }: { params: Promise<{ code: string }> }
) {
    try {
        const { code } = await params;

        const { data: room, error } = await supabase
            .from('rooms')
            .select(`
        *,
        room_members (
          *,
          users (*)
        ),
        messages (
          *,
          users (username, avatar)
        )
      `)
            .eq('code', code)
            .single();

        if (error || !room) {
            return NextResponse.json(
                { error: 'Room not found' },
                { status: 404 }
            );
        }

        // Sort messages by timestamp
        if (room.messages) {
            (room.messages as any[]).sort((a, b) =>
                new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
            );
        }

        return NextResponse.json(room);
    } catch (error) {
        console.error('Error fetching room:', error);
        return NextResponse.json(
            { error: 'Failed to fetch room' },
            { status: 500 }
        );
    }
}

// DELETE /api/rooms/[code] - Delete room (host only)
export async function DELETE(
    request: NextRequest,
    { params }: { params: Promise<{ code: string }> }
) {
    try {
        const { code } = await params;
        const { userId } = await request.json();

        const { data: room, error: fetchError } = await supabase
            .from('rooms')
            .select('*')
            .eq('code', code)
            .single();

        if (fetchError || !room) {
            return NextResponse.json(
                { error: 'Room not found' },
                { status: 404 }
            );
        }

        if (room.host_id !== userId) {
            return NextResponse.json(
                { error: 'Only the host can delete the room' },
                { status: 403 }
            );
        }

        const { error: updateError } = await supabase
            .from('rooms')
            .update({ is_active: false })
            .eq('code', code);

        if (updateError) throw updateError;

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error('Error deleting room:', error);
        return NextResponse.json(
            { error: 'Failed to delete room' },
            { status: 500 }
        );
    }
}
