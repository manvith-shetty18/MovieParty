import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';
import { nanoid } from 'nanoid';

// POST /api/rooms/[code]/join - Join a room
export async function POST(
    request: NextRequest,
    { params }: { params: Promise<{ code: string }> }
) {
    try {
        const { code } = await params;
        const { userId, username, avatar } = await request.json();

        if (!userId || !username) {
            return NextResponse.json(
                { error: 'Missing required fields' },
                { status: 400 }
            );
        }

        const { data: room, error: roomError } = await supabase
            .from('rooms')
            .select('*')
            .eq('code', code)
            .single();

        if (roomError || !room) {
            return NextResponse.json(
                { error: 'Room not found' },
                { status: 404 }
            );
        }

        // Create or upsert user
        const { error: userError } = await supabase
            .from('users')
            .upsert({
                id: userId,
                username,
                avatar,
            }, {
                onConflict: 'id',
            });

        if (userError) throw userError;

        // Check if user is already a member
        const { data: existingMember } = await supabase
            .from('room_members')
            .select('*')
            .eq('room_id', room.id)
            .eq('user_id', userId)
            .single();

        if (!existingMember) {
            const { error: memberError } = await supabase
                .from('room_members')
                .insert({
                    room_id: room.id,
                    user_id: userId,
                    is_host: false,
                });

            if (memberError) throw memberError;
        }

        // Fetch complete room with members
        const { data: updatedRoom } = await supabase
            .from('rooms')
            .select(`
        *,
        room_members (
          *,
          users (*)
        )
      `)
            .eq('code', code)
            .single();

        return NextResponse.json(updatedRoom);
    } catch (error) {
        console.error('Error joining room:', error);
        return NextResponse.json(
            { error: 'Failed to join room' },
            { status: 500 }
        );
    }
}
