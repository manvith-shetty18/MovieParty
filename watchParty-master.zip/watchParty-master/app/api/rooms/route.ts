import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';
import { nanoid } from 'nanoid';

// GET /api/rooms - List active rooms
export async function GET() {
    try {
        const { data: rooms, error } = await supabase
            .from('rooms')
            .select(`
        *,
        room_members (
          *,
          users (*)
        )
      `)
            .eq('is_active', true)
            .order('created_at', { ascending: false })
            .limit(20);

        if (error) throw error;

        return NextResponse.json(rooms);
    } catch (error) {
        console.error('Error fetching rooms:', error);
        return NextResponse.json(
            { error: 'Failed to fetch rooms' },
            { status: 500 }
        );
    }
}

// POST /api/rooms - Create a new room
export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { name, platform, videoUrl, hostId, hostUsername, hostAvatar } = body;

        if (!name || !platform || !hostId || !hostUsername) {
            return NextResponse.json(
                { error: 'Missing required fields' },
                { status: 400 }
            );
        }

        // Generate unique room code
        const code = nanoid(8);

        // Create or upsert user
        const { error: userError } = await supabase
            .from('users')
            .upsert({
                id: hostId,
                username: hostUsername,
                avatar: hostAvatar,
            }, {
                onConflict: 'id',
            });

        if (userError) throw userError;

        // Create room
        const { data: room, error: roomError } = await supabase
            .from('rooms')
            .insert({
                code,
                name,
                platform,
                video_url: videoUrl,
                host_id: hostId,
            })
            .select()
            .single();

        if (roomError) throw roomError;

        // Add host as room member
        const { error: memberError } = await supabase
            .from('room_members')
            .insert({
                room_id: room.id,
                user_id: hostId,
                is_host: true,
            });

        if (memberError) throw memberError;

        // Fetch complete room with members
        const { data: completeRoom } = await supabase
            .from('rooms')
            .select(`
        *,
        room_members (
          *,
          users (*)
        )
      `)
            .eq('id', room.id)
            .single();

        return NextResponse.json(completeRoom, { status: 201 });
    } catch (error) {
        console.error('Error creating room:', error);
        return NextResponse.json(
            { error: 'Failed to create room' },
            { status: 500 }
        );
    }
}
