'use client';

import { useState } from 'react';
import Link from 'next/link';
import { CreateRoomDialog } from '@/components/CreateRoomDialog';
import { JoinRoomDialog } from '@/components/JoinRoomDialog';
import { motion } from 'framer-motion';

export default function HomePage() {
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showJoinDialog, setShowJoinDialog] = useState(false);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section */}
      <main className="flex-1 flex items-center justify-center px-4 py-20">
        <div className="max-w-5xl w-full text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            {/* Logo / Title */}
            <h1 className="text-7xl md:text-8xl font-extrabold mb-6 gradient-text">
              WatchParty
            </h1>
            <p className="text-2xl md:text-3xl mb-4 text-text-muted">
              Watch Together, Anywhere
            </p>
            <p className="text-lg md:text-xl mb-12 text-text-muted max-w-2xl mx-auto">
              Create synchronized watch parties for Netflix, YouTube, Prime Video, and more.
              Perfect sync. Real-time chat. Ultimate viewing experience.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-20">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowCreateDialog(true)}
                className="btn btn-primary text-lg px-8 py-4 animate-pulse-glow"
              >
                🎬 Create Room
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setShowJoinDialog(true)}
                className="btn btn-secondary text-lg px-8 py-4"
              >
                🚪 Join Room
              </motion.button>
            </div>

            {/* Features Grid */}
            <div className="grid md:grid-cols-3 gap-6 mb-12">
              <FeatureCard
                icon="🎯"
                title="Perfect Sync"
                description="Play, pause, and seek in perfect synchronization with your friends"
                delay={0.2}
              />
              <FeatureCard
                icon="💬"
                title="Real-time Chat"
                description="Chat with friends while watching, share reactions instantly"
                delay={0.4}
              />
              <FeatureCard
                icon="🌍"
                title="Multi-Platform"
                description="Support for Netflix, YouTube, Prime Video, and more coming soon"
                delay={0.6}
              />
            </div>

            {/* Platform Logos */}
            <div className="glass rounded-2xl p-8">
              <h3 className="text-sm uppercase tracking-widest text-text-muted mb-6">
                Supported Platforms
              </h3>
              <div className="flex flex-wrap justify-center gap-8 items-center">
                <PlatformLogo name="YouTube" />
                <PlatformLogo name="Netflix" />
                <PlatformLogo name="Prime Video" />
                <PlatformLogo name="Custom URLs" />
              </div>
            </div>
          </motion.div>
        </div>
      </main>

      {/* Footer */}
      <footer className="py-8 text-center text-text-muted">
        <p className="text-sm">
          Built with Next.js, Socket.io, and ❤️
        </p>
      </footer>

      {/* Dialogs */}
      {showCreateDialog && (
        <CreateRoomDialog onClose={() => setShowCreateDialog(false)} />
      )}
      {showJoinDialog && (
        <JoinRoomDialog onClose={() => setShowJoinDialog(false)} />
      )}
    </div>
  );
}

function FeatureCard({
  icon,
  title,
  description,
  delay,
}: {
  icon: string;
  title: string;
  description: string;
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, delay }}
      className="card text-left"
    >
      <div className="text-5xl mb-4">{icon}</div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-text-muted">{description}</p>
    </motion.div>
  );
}

function PlatformLogo({ name }: { name: string }) {
  return (
    <motion.div
      whileHover={{ scale: 1.1 }}
      className="px-6 py-3 glass rounded-lg font-semibold text-text-muted hover:text-text transition-colors"
    >
      {name}
    </motion.div>
  );
}
