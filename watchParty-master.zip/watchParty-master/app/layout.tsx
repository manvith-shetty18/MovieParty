import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
});

export const metadata: Metadata = {
  title: "WatchParty - Watch Together, Anywhere",
  description: "Synchronized watch party platform for Netflix, YouTube, Prime Video, and more. Watch with friends in perfect sync.",
  keywords: ["watch party", "netflix", "youtube", "prime video", "synchronized viewing", "watch together"],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${inter.variable} antialiased`}>
        {children}
      </body>
    </html>
  );
}
