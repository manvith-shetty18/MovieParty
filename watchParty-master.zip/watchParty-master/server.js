const { createServer } = require('http');
const { parse } = require('url');
const next = require('next');

const dev = process.env.NODE_ENV !== 'production';
const hostname = 'localhost';
const port = parseInt(process.env.PORT || '3000', 10);

const app = next({ dev, hostname, port });
const handle = app.getRequestHandler();

app.prepare().then(async () => {
    // Dynamically import the ES module
    const socketModule = await import('./lib/socket.ts');

    // Debug: log what we got
    console.log('Socket module keys:', Object.keys(socketModule));

    // Try different ways to get the function
    const initSocketServer =
        socketModule.initSocketServer ||
        socketModule.default?.initSocketServer ||
        socketModule.default;

    if (typeof initSocketServer !== 'function') {
        console.error('initSocketServer is not a function. Module structure:', socketModule);
        throw new Error('Failed to load initSocketServer function');
    }

    const httpServer = createServer(async (req, res) => {
        try {
            const parsedUrl = parse(req.url, true);
            await handle(req, res, parsedUrl);
        } catch (err) {
            console.error('Error occurred handling', req.url, err);
            res.statusCode = 500;
            res.end('internal server error');
        }
    });

    // Initialize Socket.io
    const io = initSocketServer(httpServer);

    httpServer.once('error', (err) => {
        console.error(err);
        process.exit(1);
    });

    httpServer.listen(port, () => {
        console.log(`> Ready on http://${hostname}:${port}`);
        console.log(`> Socket.io initialized`);
    });
}).catch(err => {
    console.error('Failed to start server:', err);
    process.exit(1);
});
