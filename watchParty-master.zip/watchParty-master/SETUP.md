# 🚀 WatchParty - Quick Setup Guide

## ⚠️ IMPORTANT: Supabase Setup Required

Your server is running, but you need to configure Supabase for the database to work.

## Step 1: Create a Supabase Project (2 minutes)

1. Go to **https://supabase.com**
2. Click **"Start your project"** and sign up (free)
3. Click **"New Project"**
4. Enter:
   - **Name**: watchparty (or any name)
   - **Database Password**: Create a strong password (save it!)
   - **Region**: Choose closest to you
5. Click **"Create new project"** and wait ~2 minutes for database to initialize

## Step 2: Run the SQL Schema

1. In your Supabase dashboard, click **"SQL Editor"** in the left sidebar
2. Click **"New query"**
3. Open the file `supabase/schema.sql` in this project
4. **Copy ALL the SQL** from that file
5. **Paste it** into the Supabase SQL Editor
6. Click **"Run"** (or press Ctrl+Enter)
7. You should see "Success. No rows returned"

## Step 3: Get Your API Credentials

1. In Supabase dashboard, click **"Settings"** (gear icon in sidebar)
2. Click **"API"** under Project Settings
3. You'll see two important values:

### Copy these values:
- **Project URL**: `https://xxxxxxxxxxxxx.supabase.co`
- **anon/public key**: `eyJhbGc...` (long token)

## Step 4: Update Your .env File

Open `.env` in your project and replace the placeholders:

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-actual-project-url.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-actual-anon-key-here
NEXT_PUBLIC_APP_URL=http://localhost:3000
NEXT_PUBLIC_SOCKET_URL=http://localhost:3000
```

## Step 5: Restart the Server

1. Stop the current server (Ctrl+C in terminal)
2. Run: `tsx server.js`
3. Open http://localhost:3000
4. Try creating a room! 🎉

---

## Troubleshooting

**"Room not found" error?**
→ Supabase isn't configured. Complete steps above.

**"Failed to fetch room"?**
→ Check that your `.env` file has the correct Supabase URL and key.

**SQL errors in Supabase?**
→ Make sure you copied the ENTIRE schema.sql file content.

---

**Need help?** Check `README.md` for more detailed instructions.
