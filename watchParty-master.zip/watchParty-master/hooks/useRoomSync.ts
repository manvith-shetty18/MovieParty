'use client';

import { useEffect, useState, useCallback } from 'react';
import { Socket } from 'socket.io-client';

interface PlaybackState {
    action: 'play' | 'pause' | 'seek';
    currentTime: number;
    timestamp: number;
    userId?: string;
}

export function useRoomSync(socket: Socket | null, roomCode: string, userId: string) {
    const [playbackState, setPlaybackState] = useState<PlaybackState | null>(null);
    const [users, setUsers] = useState<any[]>([]);

    // Join room
    useEffect(() => {
        if (!socket || !roomCode) return;

        const storedUser = localStorage.getItem('watch-party-user');
        const user = storedUser ? JSON.parse(storedUser) : null;

        socket.emit('join-room', {
            roomCode,
            userId: user?.id || userId,
            username: user?.username || 'Guest',
            avatar: user?.avatar,
        });

        return () => {
            socket.emit('leave-room', {
                roomCode,
                userId: user?.id || userId,
                username: user?.username || 'Guest',
            });
        };
    }, [socket, roomCode, userId]);

    // Listen for playback sync
    useEffect(() => {
        if (!socket) return;

        const handleSyncPlayback = (state: PlaybackState) => {
            setPlaybackState(state);
        };

        const handleJoinedRoom = ({ users: roomUsers }: any) => {
            setUsers(roomUsers);
        };

        const handleUserJoined = (user: any) => {
            setUsers((prev) => [...prev, user]);
        };

        const handleUserLeft = ({ userId: leftUserId }: any) => {
            setUsers((prev) => prev.filter((u) => u.userId !== leftUserId));
        };

        socket.on('sync-playback', handleSyncPlayback);
        socket.on('joined-room', handleJoinedRoom);
        socket.on('user-joined', handleUserJoined);
        socket.on('user-left', handleUserLeft);

        return () => {
            socket.off('sync-playback', handleSyncPlayback);
            socket.off('joined-room', handleJoinedRoom);
            socket.off('user-joined', handleUserJoined);
            socket.off('user-left', handleUserLeft);
        };
    }, [socket]);

    // Emit playback updates
    const updatePlayback = useCallback(
        (action: 'play' | 'pause' | 'seek', currentTime: number) => {
            if (!socket || !roomCode) return;

            socket.emit('playback-update', {
                roomCode,
                action,
                currentTime,
                userId,
            });
        },
        [socket, roomCode, userId]
    );

    return {
        playbackState,
        updatePlayback,
        users,
    };
}
