// WatchParty Content Script - Professional with Advanced Features

(function () {
    'use strict';

    // SVG Icons
    const icons = {
        chat: '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
        send: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>',
        minimize: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/></svg>',
        users: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
        user: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
        volume: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>',
        mute: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>',
        mic: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>',
        micOff: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="1" y1="1" x2="23" y2="23"/><path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V4a3 3 0 0 0-5.94-.6"/><path d="M17 16.95A7 7 0 0 1 5 12v-2m14 0v2a7 7 0 0 1-.11 1.23"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>',
        smile: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>',
        phone: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>',
        phoneOff: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.68 13.31a16 16 0 0 0 3.41 2.6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7 2 2 0 0 1 1.72 2v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.42 19.42 0 0 1-3.33-2.67m-2.67-3.34a19.79 19.79 0 0 1-3.07-8.63A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91"/><line x1="23" y1="1" x2="1" y2="23"/></svg>',
        headphones: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg>',
        door: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>',
        lock: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
        trash: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
        circle: '<svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor" stroke="none"><circle cx="12" cy="12" r="10"/></svg>',
        settings: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
        leave: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>',
        sync: '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>',
        play: '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>',
        pause: '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>',
        online: '<svg width="8" height="8" viewBox="0 0 8 8"><circle cx="4" cy="4" r="4" fill="#10b981"/></svg>',
        speaking: '<svg width="8" height="8" viewBox="0 0 8 8"><circle cx="4" cy="4" r="4" fill="#8b5cf6"/></svg>'
    };

    // State
    let connected = false;
    let isSyncing = false;
    let lastSyncTime = 0;
    let chatPanel = null;
    let username = '';
    let roomCode = '';
    let chatMinimized = false;
    let messageHistory = [];
    let users = new Set();
    let hostUsers = new Set(); // Track who is host
    let soundEnabled = true;
    let typingTimeout = null;
    let activeTab = 'chat';
    let roomLocked = false;

    // Voice state
    let voiceActive = false;
    let voiceMuted = false;
    let voiceUsers = new Map(); // username -> { muted, speaking }

    // Permission state
    // Permission state
    let guestControls = true; // Default allowed
    let isHost = false;
    let isRestoring = false; // To prevent infinite loops when reverting actions

    // Audio for notifications
    const notifSound = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdH2Onq2rqZ6Xj4GAf3dza25xd4SPm6evs7CknZKKhoN/fXt7fYKJlZ+pr7GsoZeOiIN/fHp6fX+Fj5qkrLKwqZ+Vjo');

    // Find main video
    function getMainVideo() {
        const videos = document.querySelectorAll('video');
        if (videos.length === 0) return null;
        return Array.from(videos).reduce((largest, current) => {
            const la = (largest.offsetWidth || 0) * (largest.offsetHeight || 0);
            const ca = (current.offsetWidth || 0) * (current.offsetHeight || 0);
            return ca > la ? current : largest;
        }, videos[0]);
    }

    // Send playback update
    function sendPlayback(action, time) {
        if (!connected || isSyncing) return;
        if (Date.now() - lastSyncTime < 300) return;
        lastSyncTime = Date.now();
        chrome.runtime.sendMessage({ action: 'sendPlayback', playbackAction: action, currentTime: time });
    }

    // Attach video listeners
    function attachVideoListeners() {
        const video = getMainVideo();
        if (!video) { setTimeout(attachVideoListeners, 2000); return; }

        video.onplay = () => {
            if (isSyncing || isRestoring) return;
            if (!isHost && !guestControls) {
                addSystemMessage('Host has disabled playback controls');
                isRestoring = true;
                video.pause(); // Force pause back
                setTimeout(() => { isRestoring = false; }, 50);
                return;
            }
            sendPlayback('play', video.currentTime);
        };

        video.onpause = () => {
            if (isSyncing || isRestoring) return;
            if (!isHost && !guestControls) {
                addSystemMessage('Host has disabled playback controls');
                isRestoring = true;
                video.play().catch(() => { }); // Force play back
                setTimeout(() => { isRestoring = false; }, 50);
                return;
            }
            sendPlayback('pause', video.currentTime);
        };

        video.onseeked = () => {
            if (isSyncing || isRestoring) return;
            if (!isHost && !guestControls) {
                addSystemMessage('Host has disabled playback controls');
                // Seeking is hard to revert perfectly without storing previous time.
                // But we definitely block sending the seek event.
                return;
            }
            sendPlayback('seek', video.currentTime);
        };
    }

    // Handle sync
    function handleSync(data) {
        if (isSyncing) return;
        const video = getMainVideo();
        if (!video) return;

        isSyncing = true;
        const actionIcon = data.action === 'play' ? icons.play : data.action === 'pause' ? icons.pause : icons.sync;
        showSyncIndicator(data.action, actionIcon);

        if (data.action === 'play') { video.currentTime = data.currentTime; video.play().catch(() => { }); }
        else if (data.action === 'pause') { video.pause(); video.currentTime = data.currentTime; }
        else if (data.action === 'seek') { video.currentTime = data.currentTime; }
        setTimeout(() => { isSyncing = false; }, 500);
    }

    // Show sync indicator on video
    function showSyncIndicator(action, icon) {
        const existing = document.getElementById('wp-sync-indicator');
        if (existing) existing.remove();

        const video = getMainVideo();
        if (!video) return;
        const rect = video.getBoundingClientRect();

        const indicator = document.createElement('div');
        indicator.id = 'wp-sync-indicator';
        indicator.innerHTML = icon;
        indicator.style.cssText = `
            position: fixed;
            left: ${rect.left + rect.width / 2 - 30}px;
            top: ${rect.top + rect.height / 2 - 30}px;
            width: 60px; height: 60px;
            background: rgba(0,0,0,0.7);
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            color: white; z-index: 999999;
            animation: wpPulse 0.5s ease-out forwards;
        `;
        document.body.appendChild(indicator);
        setTimeout(() => indicator.remove(), 600);
    }

    // Create professional chat panel
    function createChatPanel() {
        if (chatPanel) return;

        // Add styles
        if (!document.getElementById('wp-styles')) {
            const style = document.createElement('style');
            style.id = 'wp-styles';
            style.textContent = `
                @keyframes wpSlideUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
                @keyframes wpPulse { 0% { transform: scale(0.5); opacity: 0; } 50% { transform: scale(1.2); opacity: 1; } 100% { transform: scale(1); opacity: 0; } }
                @keyframes wpTyping { 0%, 60%, 100% { transform: translateY(0); } 30% { transform: translateY(-4px); } }
                .wp-tab { padding: 8px 16px; border: none; background: transparent; color: #6b7280; cursor: pointer; font-size: 13px; font-weight: 500; border-bottom: 2px solid transparent; transition: all 0.2s; }
                .wp-tab:hover { color: #9ca3af; }
                .wp-tab.active { color: #a78bfa; border-bottom-color: #8b5cf6; }
                .wp-reaction { padding: 4px 8px; background: rgba(139, 92, 246, 0.2); border-radius: 12px; cursor: pointer; transition: all 0.2s; }
                .wp-reaction:hover { background: rgba(139, 92, 246, 0.4); transform: scale(1.1); }
                .wp-user-item { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 8px; transition: all 0.2s; }
                .wp-user-item:hover { background: rgba(255,255,255,0.05); }
                #wp-chat-input:focus { background: #252538 !important; box-shadow: 0 0 0 2px rgba(139, 92, 246, 0.3); }
            `;
            document.head.appendChild(style);
        }

        chatPanel = document.createElement('div');
        chatPanel.id = 'wp-chat-panel';

        // Event Delegation for dynamic elements
        chatPanel.addEventListener('change', (e) => {
            if (e.target.id === 'wp-guest-control-toggle') {
                const allowed = e.target.checked;
                chrome.runtime.sendMessage({ action: 'updatePermissions', guestControls: allowed });
            }
            if (e.target.id === 'wp-lock-toggle') {
                const locked = e.target.checked;
                chrome.runtime.sendMessage({ action: 'lockRoom', locked });
            }
        });

        // Click Delegation
        chatPanel.addEventListener('click', (e) => {
            const target = e.target;

            // Copy Code
            const copyBtn = target.closest('#wp-copy-code');
            if (copyBtn) {
                navigator.clipboard.writeText(roomCode).then(() => {
                    const originalHtml = copyBtn.innerHTML;
                    copyBtn.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>';
                    setTimeout(() => { copyBtn.innerHTML = originalHtml; }, 2000);
                });
                return;
            }

            // Leave
            if (target.closest('#wp-leave-btn')) {
                chrome.runtime.sendMessage({ action: 'disconnect' });
                // Reset local state
                connected = false;
                if (chatPanel) {
                    chatPanel.remove();
                    chatPanel = null;
                }
                messageHistory = [];
                users.clear();
                hostUsers.clear();
                voiceUsers.clear();

                if (voiceActive) chrome.runtime.sendMessage({ action: 'stopVoice' });
                voiceActive = false;
                return;
            }

            // Kick User
            const kickBtn = target.closest('.wp-kick-btn');
            if (kickBtn) {
                const user = kickBtn.dataset.user;
                if (confirm(`Are you sure you want to kick ${user}?`)) {
                    chrome.runtime.sendMessage({ action: 'kickUser', username: user });
                }
                return;
            }

            // Reaction Toggle
            if (target.closest('#wp-reaction-btn')) {
                const popup = document.getElementById('wp-reaction-popup');
                if (popup) popup.style.display = popup.style.display === 'grid' ? 'none' : 'grid';
                e.stopPropagation();
                return;
            }

            // Quick Reaction Item
            const reactionBtn = target.closest('.wp-quick-reaction');
            if (reactionBtn) {
                sendReaction(reactionBtn.dataset.reaction);
                const popup = document.getElementById('wp-reaction-popup');
                if (popup) popup.style.display = 'none';
                return;
            }

            // Send Chat
            if (target.closest('#wp-send')) {
                sendChatMessage();
                return;
            }

            // Minimize
            if (target.closest('#wp-minimize')) {
                toggleChat();
                return;
            }

            // Tabs
            const tabBtn = target.closest('.wp-tab');
            if (tabBtn) {
                activeTab = tabBtn.dataset.tab;
                renderFullChat();
                return;
            }

            // Sound Toggle
            if (target.closest('#wp-sound-btn')) {
                toggleSound();
                return;
            }

            // Voice Actions
            if (target.closest('#wp-join-voice-btn')) {
                chrome.runtime.sendMessage({ action: 'startVoice' }, (res) => {
                    if (res && res.success) {
                        voiceActive = true;
                        voiceUsers.set(username, { muted: false });
                        renderFullChat();
                    } else addSystemMessage('Microphone access denied');
                });
                return;
            }
            if (target.closest('#wp-leave-voice-btn')) {
                chrome.runtime.sendMessage({ action: 'stopVoice' });
                voiceActive = false;
                voiceMuted = false;
                voiceUsers.delete(username);
                renderFullChat();
                return;
            }
            if (target.closest('#wp-mute-btn')) {
                voiceMuted = !voiceMuted;
                chrome.runtime.sendMessage({ action: 'toggleMute', muted: voiceMuted });
                voiceUsers.set(username, { muted: voiceMuted });
                renderFullChat();
                return;
            }

            // Close popup if clicking elsewhere
            const popup = document.getElementById('wp-reaction-popup');
            if (popup && popup.style.display === 'grid' && !target.closest('#wp-reaction-popup')) {
                popup.style.display = 'none';
            }
        });

        // Input delegation (Enter key)
        chatPanel.addEventListener('keypress', (e) => {
            if (e.target.id === 'wp-chat-input' && e.key === 'Enter') {
                sendChatMessage();
            }
        });

        // Typing indicator
        chatPanel.addEventListener('input', (e) => {
            if (e.target.id === 'wp-chat-input') {
                handleTyping();
            }
        });

        renderFullChat();
        document.body.appendChild(chatPanel);
        restoreMessages();

        // Handle Fullscreen
        document.addEventListener('fullscreenchange', () => {
            const fsElement = document.fullscreenElement;
            if (fsElement && chatPanel) {
                fsElement.appendChild(chatPanel);
            } else if (chatPanel) {
                document.body.appendChild(chatPanel);
            }
        });
    }

    function renderFullChat() {
        const userCount = users.size || 1;
        chatPanel.innerHTML = `
            <div id="wp-chat-container" style="
                position: fixed; bottom: 20px; right: 20px; width: 360px; height: 480px;
                background: #0f0f1a;
                border-radius: 14px; display: flex; flex-direction: column;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                z-index: 999999;
                box-shadow: 0 8px 32px rgba(0,0,0,0.5);
                border: 1px solid rgba(255,255,255,0.08);
                overflow: hidden;
            ">
                <!-- Header -->
                <div style="
                    padding: 12px 16px;
                    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                    border-bottom: 1px solid rgba(255,255,255,0.08);
                    display: flex; justify-content: space-between; align-items: center;
                ">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <div style="
                            width: 36px; height: 36px; border-radius: 10px;
                            background: linear-gradient(135deg, #8b5cf6, #ec4899);
                            display: flex; align-items: center; justify-content: center;
                            box-shadow: 0 4px 12px rgba(139, 92, 246, 0.3);
                        ">
                            <img src="${chrome.runtime.getURL('assets/icon-128.png')}" style="width: 20px; height: 20px; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.2));" />
                        </div>
                        <div style="display: flex; flex-direction: column;">
                            <div style="font-weight: 700; font-size: 14px; color: white; letter-spacing: 0.5px; display: flex; align-items: center; gap: 6px;">
                                watchParty
                                ${roomLocked ? `<span style="color: #ec4899; display: flex;">${icons.lock}</span>` : ''}
                            </div>
                            <div style="font-size: 10px; color: #9ca3af; display: flex; align-items: center; gap: 4px;">
                                <span style="color: ${connected ? '#10b981' : '#ef4444'}; display: flex;">${icons.circle}</span>
                                ${connected ? 'Connected' : 'Disconnected'}
                                <span style="margin: 0 4px; color: #4b5563;">|</span>
                                <span style="font-family: monospace; font-weight: 700; color: #d1d5db; letter-spacing: 0.5px;">${roomCode}</span>
                                <button id="wp-copy-code" style="
                                    background: none; border: none; padding: 2px; margin-left: 4px;
                                    color: #9ca3af; cursor: pointer; display: flex;
                                    transition: color 0.2s;
                                " title="Copy Code">
                                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div style="display: flex; gap: 8px;">
                        <button id="wp-minimize" style="
                            padding: 6px; background: rgba(255,255,255,0.05); border: none; border-radius: 6px;
                            color: #9ca3af; cursor: pointer; transition: all 0.2s; display: flex;
                        ">${icons.minimize}</button>
                        <button id="wp-leave-btn" style="
                            padding: 6px; background: rgba(239, 68, 68, 0.1); border: none; border-radius: 6px;
                            color: #ef4444; cursor: pointer; transition: all 0.2s; display: flex;
                        ">${icons.leave}</button>
                    </div>
                </div>
                <!-- Tabs -->
                <div style="display: flex; border-bottom: 1px solid rgba(255,255,255,0.08); background: #0a0a12;">
                    <button class="wp-tab ${activeTab === 'chat' ? 'active' : ''}" data-tab="chat">Chat</button>
                    <button class="wp-tab ${activeTab === 'voice' ? 'active' : ''}" data-tab="voice">Voice</button>
                    <button class="wp-tab ${activeTab === 'users' ? 'active' : ''}" data-tab="users">Users (${userCount})</button>
                    ${isHost ? `<button class="wp-tab ${activeTab === 'controls' ? 'active' : ''}" data-tab="controls">Controls</button>` : ''}
                </div>

                <!-- Content -->
                <div id="wp-tab-content" style="flex: 1; overflow: hidden; display: flex; flex-direction: column;">
                    ${activeTab === 'chat' ? renderChatTab() :
                activeTab === 'voice' ? renderVoiceTab() :
                    activeTab === 'controls' ? renderControlsTab() :
                        renderUsersTab()}
                </div>

                <!-- Input (only for chat tab) -->
                ${activeTab === 'chat' ? `
                <div style="
                    padding: 12px; background: #0f0f1a;
                    border-top: 1px solid rgba(255,255,255,0.08);
                ">
                    <div id="wp-typing" style="font-size: 11px; color: #6b7280; margin-bottom: 6px; height: 14px;"></div>
                    <div style="display: flex; gap: 8px;">
                        <input type="text" id="wp-chat-input" placeholder="Type a message..." style="
                            flex: 1; padding: 12px 14px; border: none; border-radius: 8px;
                            background: #1a1a2e; color: white; font-size: 14px;
                            outline: none; transition: all 0.2s;
                        " />
                        <button id="wp-reaction-btn" style="
                            padding: 12px 12px; border: none; border-radius: 8px;
                            background: rgba(255,255,255,0.1); color: #fbbf24; cursor: pointer;
                            display: flex; align-items: center; justify-content: center;
                        ">${icons.smile}</button>
                        <button id="wp-send" style="
                            padding: 12px 14px; border: none; border-radius: 8px;
                            background: linear-gradient(135deg, #8b5cf6, #ec4899);
                            color: white; cursor: pointer;
                            display: flex; align-items: center; justify-content: center;
                        ">${icons.send}</button>
                    </div>
                </div>
                ` : ''}
                
                <!-- Reaction Popup -->
                <div id="wp-reaction-popup" style="
                    position: absolute; bottom: 80px; right: 20px;
                    background: #1a1a2e; border: 1px solid rgba(255,255,255,0.1);
                    border-radius: 12px; padding: 12px;
                    display: none; grid-template-columns: repeat(4, 1fr); gap: 8px;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.5); z-index: 999999;
                ">
                    ${['👍', '❤️', '😂', '😮', '😢', '😘', '🔥', '👏'].map(r =>
                            `<button class="wp-quick-reaction" data-reaction="${r}" style="
                            font-size: 24px; background: transparent; border: none; 
                            cursor: pointer; padding: 8px; border-radius: 8px;
                            transition: background 0.2s;
                        ">${r}</button>`
                        ).join('')}
                </div>
            </div>
        `;

        attachEventListeners();
        restoreMessages();
    }

    function renderChatTab() {
        return `<div id="wp-messages" style="flex: 1; overflow-y: auto; padding: 12px; display: flex; flex-direction: column; gap: 8px; background: #0a0a12;"></div>`;
    }

    function renderUsersTab() {
        const userList = Array.from(users);
        if (userList.length === 0) userList.push(username);

        return `
            <div style="flex: 1; overflow-y: auto; padding: 12px; background: #0a0a12; display: flex; flex-direction: column; gap: 8px;">
                 <div style="color: #6b7280; font-size: 11px; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 1px;">
                    Online Members
                </div>
                ${userList.map((name, index) => {
            const isMe = name === username;
            // Check set OR local variable for self
            const isUserHost = hostUsers.has(name) || (isMe && isHost);
            return `
                    <div class="wp-user-item" style="
                        display: flex; align-items: center; justify-content: space-between;
                        padding: 10px 12px; background: rgba(255,255,255,0.03); 
                        border: 1px solid rgba(255,255,255,0.05); border-radius: 6px;
                    ">
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <span style="font-family: monospace; color: #4b5563; font-size: 12px;">${String(index + 1).padStart(2, '0')}</span>
                            <div style="font-weight: 500; font-size: 13px; color: ${isMe ? '#a78bfa' : 'white'};">
                                ${name} ${isMe ? '(You)' : ''}
                            </div>
                        </div>
                        
                        <div style="display: flex; align-items: center; gap: 8px;">
                             ${isUserHost ?
                    `<span style="font-size: 9px; font-weight: 700; background: #8b5cf6; color: white; padding: 2px 6px; border-radius: 4px;">HOST</span>`
                    :
                    `<span style="font-size: 9px; font-weight: 700; background: #374151; color: #9ca3af; padding: 2px 6px; border-radius: 4px;">GUEST</span>`
                }
                             ${isHost && !isMe ? `<button class="wp-kick-btn" data-user="${name}" style="background: none; border: none; color: #ef4444; cursor: pointer; display: flex;">${icons.trash}</button>` : ''}
                             <div style="width: 6px; height: 6px; border-radius: 50%; background: #10b981;"></div>
                        </div>
                    </div>`;
        }).join('')}
            </div>
        `;
    }

    function renderReactionsTab() {
        const reactions = ['👍', '❤️', '😂', '😮', '😢', '😘', '🔥', '👏'];
        return `
            <div style="flex: 1; padding: 16px; background: #0a0a12; display: flex; flex-direction: column; gap: 16px;">
                <div style="color: #9ca3af; font-size: 13px;">Send a reaction to everyone</div>
                <div style="display: flex; flex-wrap: wrap; gap: 12px; justify-content: center;">
                    ${reactions.map(r => `<button class="wp-reaction" data-reaction="${r}" style="font-size: 28px; border: none;">${r}</button>`).join('')}
                </div>
                <div style="color: #6b7280; font-size: 11px; text-align: center; margin-top: auto;">
                    Reactions appear on everyone's screen
                </div>
            </div>
        `;
    }

    function renderVoiceTab() {
        const voiceUserList = Array.from(voiceUsers.entries());
        return `
            <div style="flex: 1; padding: 16px; background: #0a0a12; display: flex; flex-direction: column; gap: 16px;">
                <div style="text-align: center; padding: 20px 0;">
                    ${voiceActive ? `
                        <div style="color: #10b981; font-size: 13px; margin-bottom: 16px;">
                            ${icons.headphones} Voice connected
                        </div>
                        <div style="display: flex; justify-content: center; gap: 12px;">
                            <button id="wp-mute-btn" style="
                                width: 56px; height: 56px; border-radius: 50%;
                                background: ${voiceMuted ? '#ef4444' : 'rgba(255,255,255,0.1)'};
                                border: none; color: white; cursor: pointer;
                                display: flex; align-items: center; justify-content: center;
                                transition: all 0.2s;
                            ">${voiceMuted ? icons.micOff : icons.mic}</button>
                            <button id="wp-leave-voice-btn" style="
                                width: 56px; height: 56px; border-radius: 50%;
                                background: #ef4444;
                                border: none; color: white; cursor: pointer;
                                display: flex; align-items: center; justify-content: center;
                                transition: all 0.2s;
                            ">${icons.phoneOff}</button>
                        </div>
                        <div style="color: #6b7280; font-size: 11px; margin-top: 12px;">
                            ${voiceMuted ? 'Muted' : 'Unmuted'} · Click to ${voiceMuted ? 'unmute' : 'mute'}
                        </div>
                    ` : `
                        <div style="color: #9ca3af; font-size: 13px; margin-bottom: 16px;">
                            Talk with other viewers
                        </div>
                        <button id="wp-join-voice-btn" style="
                            padding: 16px 32px; border-radius: 50px;
                            background: linear-gradient(135deg, #8b5cf6, #ec4899);
                            border: none; color: white; cursor: pointer;
                            font-size: 14px; font-weight: 600;
                            display: inline-flex; align-items: center; gap: 8px;
                            transition: all 0.2s;
                        ">${icons.phone} Join Voice</button>
                        <div style="color: #6b7280; font-size: 11px; margin-top: 12px;">
                            Requires microphone permission
                        </div>
                    `}
                </div>
                
                ${voiceUserList.length > 0 ? `
                    <div style="border-top: 1px solid rgba(255,255,255,0.08); padding-top: 16px;">
                        <div style="color: #6b7280; font-size: 11px; margin-bottom: 12px; text-transform: uppercase; letter-spacing: 0.5px;">
                            In Voice (${voiceUserList.length})
                        </div>
                        ${voiceUserList.map(([name, info]) => `
                            <div style="display: flex; align-items: center; gap: 10px; padding: 8px 0;">
                                <div style="
                                    width: 32px; height: 32px; border-radius: 50%;
                                    background: ${info.muted ? '#4b5563' : '#8b5cf6'};
                                    display: flex; align-items: center; justify-content: center;
                                    color: white;
                                ">${info.muted ? icons.micOff : icons.mic}</div>
                                <div style="color: white; font-size: 13px;">${name}${name === username ? ' (you)' : ''}</div>
                                ${info.muted ? '<span style="color: #6b7280; font-size: 11px;">Muted</span>' : ''}
                            </div>
                        `).join('')}
                    </div>
                ` : ''}
            </div>
        `;
    }

    function renderControlsTab() {
        return `
            <div style="flex: 1; padding: 16px; background: #0a0a12; display: flex; flex-direction: column; gap: 16px;">
                 <div style="background: rgba(255,255,255,0.05); padding: 12px; border-radius: 10px;">
                    <div style="font-size: 11px; font-weight: 600; color: #6b7280; margin-bottom: 10px; text-transform: uppercase;">Host Controls</div>
                    <div style="display: flex; align-items: center; justify-content: space-between;">
                        <div style="color: white; font-size: 13px;">Allow Guest Control</div>
                        <label class="switch" style="position: relative; display: inline-block; width: 40px; height: 22px;">
                            <input type="checkbox" id="wp-guest-control-toggle" ${guestControls ? 'checked' : ''}>
                            <span class="slider round" style="
                                position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0;
                                background-color: #4b5563; transition: .4s; border-radius: 34px;
                            "></span>
                            <style>
                                .slider:before {
                                    position: absolute; content: ""; height: 16px; width: 16px;
                                    left: 3px; bottom: 3px; background-color: white;
                                    transition: .4s; border-radius: 50%;
                                }
                                input:checked + .slider { background-color: #8b5cf6; }
                                input:checked + .slider:before { transform: translateX(18px); }
                            </style>
                        </label>
                    </div>
                    <div style="color: #6b7280; font-size: 11px; margin-top: 8px;">
                        When disabled, only the host can play, pause, or seek the video.
                    </div>
                </div>

                 <div style="background: rgba(255,255,255,0.05); padding: 12px; border-radius: 10px;">
                    <div style="font-size: 11px; font-weight: 600; color: #6b7280; margin-bottom: 10px; text-transform: uppercase;">Room Security</div>
                    <div style="display: flex; align-items: center; justify-content: space-between;">
                        <div style="color: white; font-size: 13px;">Lock Room</div>
                        <label class="switch" style="position: relative; display: inline-block; width: 40px; height: 22px;">
                            <input type="checkbox" id="wp-lock-toggle" ${roomLocked ? 'checked' : ''}>
                            <span class="slider round" style="
                                position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0;
                                background-color: #4b5563; transition: .4s; border-radius: 34px;
                            "></span>
                            <style>
                                input:checked + .slider { background-color: #ec4899; }
                            </style>
                        </label>
                    </div>
                    <div style="color: #6b7280; font-size: 11px; margin-top: 8px;">
                        When locked, no new users can join the room.
                    </div>
                </div>
            </div>
        `;
    }


    function attachEventListeners() {
        // Legacy function kept for interface compatibility but empty
        // All events now handled via delegation in createChatPanel
    }

    function restoreMessages() {
        const container = document.getElementById('wp-messages');
        if (!container) return;
        messageHistory.forEach(m => {
            if (m.type === 'system') addSystemMessageDOM(container, m.text);
            else addMessageDOM(container, m.sender, m.text, m.isMe);
        });
        container.scrollTop = container.scrollHeight;
    }

    function renderMinimized() {
        chatPanel.innerHTML = `
            <div id="wp-chat-icon" style="
                position: fixed; bottom: 20px; right: 20px;
                width: 56px; height: 56px; border-radius: 50%;
                background: linear-gradient(135deg, #8b5cf6, #ec4899);
                display: flex; align-items: center; justify-content: center;
                color: white; cursor: pointer; z-index: 999999;
                box-shadow: 0 4px 20px rgba(139, 92, 246, 0.4);
                transition: all 0.2s;
            ">${icons.chat}</div>
        `;
        const icon = document.getElementById('wp-chat-icon');
        icon.onclick = toggleChat;
        icon.onmouseover = () => {
            icon.style.transform = 'scale(1.1)';
            icon.style.boxShadow = '0 6px 28px rgba(139, 92, 246, 0.6)';
        };
        icon.onmouseout = () => {
            icon.style.transform = 'scale(1)';
            icon.style.boxShadow = '0 4px 20px rgba(139, 92, 246, 0.4)';
        };
    }

    function toggleChat() {
        chatMinimized = !chatMinimized;
        if (chatMinimized) renderMinimized();
        else renderFullChat();
    }

    function toggleSound() {
        soundEnabled = !soundEnabled;
        const btn = document.getElementById('wp-sound-btn');
        if (btn) btn.innerHTML = soundEnabled ? icons.volume : icons.mute;
    }

    function handleTyping() {
        chrome.runtime.sendMessage({ action: 'sendTyping' });
    }

    function showTypingIndicator(user) {
        const el = document.getElementById('wp-typing');
        if (el && user !== username) {
            el.textContent = `${user} is typing...`;
            clearTimeout(typingTimeout);
            typingTimeout = setTimeout(() => { el.textContent = ''; }, 2000);
        }
    }

    function sendChatMessage() {
        const input = document.getElementById('wp-chat-input');
        const message = input.value.trim();
        if (!message) return;

        chrome.runtime.sendMessage({ action: 'sendChat', message });
        addMessage(username || 'You', message, true);
        input.value = '';
    }

    function sendReaction(emoji) {
        chrome.runtime.sendMessage({ action: 'sendReaction', emoji });
        showFloatingReaction(emoji);
    }

    function showFloatingReaction(emoji) {
        const video = getMainVideo();
        if (!video) return;
        const rect = video.getBoundingClientRect();

        // Create a burst of particles
        const particleCount = 12;

        // Ensure animation keyframes exist
        if (!document.getElementById('wp-reaction-anim')) {
            const style = document.createElement('style');
            style.id = 'wp-reaction-anim';
            style.textContent = `
                @keyframes wpFloatUp { 
                    0% { opacity: 0; transform: translateY(0) scale(0.5) rotate(0deg); }
                    10% { opacity: 1; transform: translateY(-20px) scale(1.2) rotate(var(--rot)); }
                    100% { opacity: 0; transform: translateY(-300px) translateX(var(--x-drift)) scale(1) rotate(var(--rot-end)); }
                }
            `;
            document.head.appendChild(style);
        }

        for (let i = 0; i < particleCount; i++) {
            const reaction = document.createElement('div');
            reaction.textContent = emoji;

            // Random physics
            const startX = rect.left + Math.random() * rect.width * 0.8 + rect.width * 0.1;
            const size = 32 + Math.random() * 24; // 32-56px
            const duration = 1.5 + Math.random() * 1.5; // 1.5-3s
            const drift = (Math.random() - 0.5) * 100 + 'px'; // -50 to +50px drift
            const rotation = (Math.random() - 0.5) * 40 + 'deg';
            const rotationEnd = (Math.random() - 0.5) * 90 + 'deg';
            const delay = Math.random() * 0.3; // Slight burst staggered

            reaction.style.cssText = `
                position: fixed;
                left: ${startX}px;
                bottom: ${window.innerHeight - rect.bottom + 20}px;
                font-size: ${size}px;
                z-index: 999999;
                pointer-events: none;
                --x-drift: ${drift};
                --rot: ${rotation};
                --rot-end: ${rotationEnd};
                animation: wpFloatUp ${duration}s ease-out forwards;
                animation-delay: ${delay}s;
                opacity: 0; 
                text-shadow: 0 2px 10px rgba(0,0,0,0.3);
            `;

            const targetContainer = document.fullscreenElement || document.body;
            targetContainer.appendChild(reaction);
            setTimeout(() => reaction.remove(), duration * 1000 + 500);
        }
    }

    function addMessageDOM(container, sender, text, isMe) {
        const div = document.createElement('div');
        div.style.cssText = `
            margin-bottom: 8px;
            display: flex; flex-direction: column;
            align-items: ${isMe ? 'flex-end' : 'flex-start'};
        `;
        div.innerHTML = `
            <div style="font-size: 11px; color: rgba(255,255,255,0.7); margin-bottom: 3px; display: flex; align-items: center; gap: 4px;">
                ${isMe ? '' : `<span style="font-weight: 600;">${sender}</span>`}
            </div>
            <div style="
                max-width: 85%; padding: 8px 12px;
                background: ${isMe ? 'linear-gradient(135deg, #8b5cf6, #ec4899)' : 'rgba(255, 255, 255, 0.1)'};
                border-radius: ${isMe ? '12px 12px 2px 12px' : '12px 12px 12px 2px'};
                color: white; font-size: 13px; line-height: 1.4;
                word-break: break-word;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            ">${text}</div>
            <div style="font-size: 10px; color: rgba(255,255,255,0.3); margin-top: 2px;">
                ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </div>
        `;
        container.appendChild(div);
        container.scrollTop = container.scrollHeight;
    }

    function addMessage(sender, text, isMe = false) {
        messageHistory.push({ sender, text, isMe });
        const container = document.getElementById('wp-messages');
        if (container) addMessageDOM(container, sender, text, isMe);
    }

    function addSystemMessageDOM(container, text) {
        const div = document.createElement('div');
        div.style.cssText = 'text-align: center; margin: 12px 0; font-size: 11px; color: #6b7280; display: flex; align-items: center; justify-content: center; gap: 8px;';
        div.innerHTML = `
            <div style="height: 1px; background: rgba(255,255,255,0.1); flex: 1;"></div>
            <span>${text}</span>
            <div style="height: 1px; background: rgba(255,255,255,0.1); flex: 1;"></div>
        `;
        container.appendChild(div);
        container.scrollTop = container.scrollHeight;
    }

    function addSystemMessage(text) {
        messageHistory.push({ type: 'system', text });
        const container = document.getElementById('wp-messages');
        if (container) addSystemMessageDOM(container, text);
    }

    function showChatNotification(sender, text) {
        if (soundEnabled) {
            try { notifSound.play().catch(() => { }); } catch (e) { }
        }

        const existing = document.getElementById('wp-chat-notif');
        if (existing) existing.remove();

        const notif = document.createElement('div');
        notif.id = 'wp-chat-notif';
        notif.onclick = () => { if (chatMinimized) toggleChat(); notif.remove(); };
        notif.style.cssText = `
        position: fixed; bottom: 90px; right: 20px; z-index: 999999;
        background: #1a1a2e; color: white;
        padding: 12px 16px; border-radius: 10px; max-width: 280px;
        font: 14px -apple-system, sans-serif;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4); cursor: pointer;
        border: 1px solid rgba(139, 92, 246, 0.3);
        animation: wpSlideUp 0.3s ease-out;
        `;
        notif.innerHTML = `
            <div style="font-weight: 600; margin-bottom: 4px; display: flex; align-items: center; gap: 6px;">
                ${icons.user} ${sender}
            </div>
            <div style="color: #9ca3af;">${text.length > 50 ? text.substring(0, 50) + '...' : text}</div>
        `;
        document.body.appendChild(notif);
        setTimeout(() => notif.remove(), 5000);
    }

    // Listen for messages
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
        if (msg.type === 'connected') {
            connected = true;
            username = msg.username || 'User';
            roomCode = msg.roomCode || 'room';
            isHost = msg.isHost || false; // Capture isHost!
            users.add(username);
            createChatPanel();
            addSystemMessage(`Connected to room${isHost ? ' as Host' : ''} `);
            attachVideoListeners();
        } else if (msg.type === 'sync') {
            handleSync(msg.data);
        } else if (msg.type === 'chat') {
            if (msg.data.username !== username) {
                addMessage(msg.data.username, msg.data.message, false);
                users.add(msg.data.username);
                if (chatMinimized) showChatNotification(msg.data.username, msg.data.message);
            }
        } else if (msg.type === 'user-joined') {
            users.add(msg.data.username);
            addSystemMessage(`${msg.data.username} joined`);
            if (!chatMinimized) renderFullChat();
        } else if (msg.type === 'user-left') {
            users.delete(msg.data.username);
            addSystemMessage(`${msg.data.username} left`);
            if (!chatMinimized) renderFullChat();
        } else if (msg.type === 'reaction') {
            console.log('[WatchParty] Received reaction:', msg.data);
            showFloatingReaction(msg.data.emoji);
        } else if (msg.type === 'typing') {
            showTypingIndicator(msg.data.username);
        } else if (msg.type === 'room-users') {
            // Received full list of users
            users = new Set();
            hostUsers = new Set();
            msg.data.forEach(u => {
                users.add(u.username);
                if (u.isHost) hostUsers.add(u.username);
            });

            // If we are on Viewers tab, re-render
            if (activeTab === 'users' && !chatMinimized) {
                renderFullChat(); // Use full chat render to update tab count too
            }
        } else if (msg.type === 'permissions-updated') {
            guestControls = msg.data.guestControls;
            if (!isHost) {
                addSystemMessage(guestControls ? 'Host enabled controls' : 'Host disabled controls');
            }
        } else if (msg.type === 'voice-started') {
            voiceActive = true;
            voiceUsers.set(msg.data.username, { muted: false });
            addSystemMessage(`You joined voice chat`);
            if (!chatMinimized) renderFullChat();
        } else if (msg.type === 'voice-stopped') {
            voiceActive = false;
            voiceMuted = false;
            if (!chatMinimized) renderFullChat();
        } else if (msg.type === 'voice-user-joined') {
            voiceUsers.set(msg.data.username, { muted: false });
            addSystemMessage(`${msg.data.username} joined voice`);
            if (!chatMinimized) renderFullChat();
        } else if (msg.type === 'voice-user-left') {
            voiceUsers.delete(msg.data.username);
            addSystemMessage(`${msg.data.username} left voice`);
            if (!chatMinimized) renderFullChat();
        } else if (msg.type === 'voice-mute-changed') {
            voiceMuted = msg.data.muted;
            voiceUsers.set(username, { muted: voiceMuted });
            if (!chatMinimized) renderFullChat();
        } else if (msg.type === 'voice-connected') {
            addSystemMessage(`Voice connected with ${msg.data.username} `);
        } else if (msg.type === 'user-kicked') {
            users.delete(msg.data.username);
            addSystemMessage(`${msg.data.username} was kicked from the room`);
            if (activeTab === 'users' && !chatMinimized) renderUsersTab();
        } else if (msg.type === 'kicked') {
            // Disconnect self
            connected = false;
            chrome.runtime.sendMessage({ action: 'disconnect' });
            if (chatPanel) {
                chatPanel.remove();
                chatPanel = null;
            }
            alert('You have been kicked from the room by the host.');
        } else if (msg.type === 'room-locked') {
            roomLocked = msg.data.locked;
            if (!chatMinimized) {
                renderFullChat(); // re-render header/controls
            }
            addSystemMessage(roomLocked ? 'Room has been locked by the host' : 'Room has been unlocked');
        } else if (msg.type === 'error') {
            addSystemMessage('Connection error');
        } else if (msg.type === 'disconnected') {
            connected = false;
            voiceActive = false;
            addSystemMessage('Disconnected');
        } else if (msg.action === 'connect') {
            chrome.runtime.sendMessage(msg, sendResponse);
            return true;
        } else if (msg.action === 'getVideoInfo') {
            const v = getMainVideo();
            sendResponse({ hasVideo: !!v, duration: v?.duration || 0 });
        }
        return true;
    });

    // Check connection status on load
    chrome.runtime.sendMessage({ action: 'getStatus' }, (response) => {
        if (response && response.connected) {
            console.log('[WatchParty] Restoring connection state...');
            connected = true;
            username = response.username;
            roomCode = response.room;
            isHost = response.isHost || false; // Capture isHost!

            users.add(username);
            if (isHost) hostUsers.add(username); // Ensure we are tracked as host

            createChatPanel();
            addSystemMessage(`Restored connection${isHost ? ' as Host' : ''} `);
            attachVideoListeners();

            if (response.voiceActive) {
                activeTab = 'voice';
                voiceActive = true;
                voiceUsers.set(username, { muted: false });
            }
            renderFullChat();
        }
    });

    console.log('[WatchParty] Professional extension ready');
})();
