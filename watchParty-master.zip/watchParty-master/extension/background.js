// WatchParty Background Script - With Voice Chat Support
importScripts('socket.io.min.js');

let socket = null;
let currentRoom = null;
let username = 'User';
let isHost = false;
let hostUrl = null;
let peerConnections = new Map();
let localStream = null;

// ICE servers for WebRTC
const iceServers = {
    iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' }
    ]
};

// Connect to server
function connect(roomCode, name, host = false, url = null) {
    return new Promise((resolve, reject) => {
        try {
            currentRoom = roomCode;
            if (name) username = name;
            isHost = host;
            if (url) hostUrl = url;

            if (socket) socket.disconnect();

            if (typeof io === 'undefined') {
                console.error('Socket.io library not loaded');
                reject(new Error('Socket.io library not loaded'));
                return;
            }

            socket = io('http://localhost:3000', {
                transports: ['websocket', 'polling'], // Try websocket first, then polling
                upgrade: true,
                reconnectionAttempts: 3
            });

            const timeout = setTimeout(() => {
                reject(new Error('Connection timeout'));
                socket.disconnect();
            }, 5000);

            socket.on('connect', () => {
                clearTimeout(timeout);
                console.log('[WatchParty BG] Connected:', socket.id);
                socket.emit('extension-join', {
                    roomCode,
                    username,
                    isHost,
                    hostUrl: isHost ? hostUrl : null
                });

                // Save state to storage
                chrome.storage.local.set({
                    connectionState: { roomCode, username, isHost, hostUrl }
                });

                broadcastToTabs({ type: 'connected', username, roomCode, isHost });
                resolve(true); // Connected successfully
            });

            socket.on('connect_error', (err) => {
                console.error('[WatchParty BG] Connect Error:', err.message);
                // Don't reject immediately on first error, let it retry or timeout
            });

            socket.on('error', (err) => {
                console.error('[WatchParty BG] Socket Error:', err);
                broadcastToTabs({ type: 'error', message: err.message || 'Socket error' });
                // If we are still pending connection, reject?
                // But connect() might have already resolved.
            });

            // ... (rest of listeners) ...
            setupSocketListeners();

        } catch (e) {
            reject(e);
        }
    });
}

function setupSocketListeners() {
    socket.on('sync-playback', (data) => {
        broadcastToTabs({ type: 'sync', data });
    });

    socket.on('chat-message', (data) => {
        broadcastToTabs({ type: 'chat', data });
    });

    socket.on('user-joined-ext', (data) => {
        broadcastToTabs({ type: 'user-joined', data });
    });

    socket.on('user-joined', (data) => {
        broadcastToTabs({ type: 'user-joined', data });
    });

    socket.on('user-left-ext', (data) => {
        broadcastToTabs({ type: 'user-left', data });
    });

    socket.on('user-left', (data) => {
        broadcastToTabs({ type: 'user-left', data });
    });

    socket.on('user-disconnected', (data) => {
        // content.js expects { username } but this event usually has { socketId }
        // For now we might not be able to map socketId to username easily without keeping state
        // But let's broadcast it anyway if content.js can handle it or just ignore for now
        // A better approach is trusting user-left which has username
    });

    // Receive host URL when joining as guest
    socket.on('room-info', (data) => {
        console.log('[WatchParty BG] Room info:', data);
        if (!isHost && data.hostUrl) {
            // Redirect guest to host URL
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs[0] && tabs[0].url !== data.hostUrl) {
                    chrome.tabs.update(tabs[0].id, { url: data.hostUrl });
                    broadcastToTabs({ type: 'redirect', url: data.hostUrl });
                }
            });
        }
    });

    socket.on('room-users', (data) => {
        broadcastToTabs({ type: 'room-users', data });
    });

    socket.on('reaction', (data) => {
        broadcastToTabs({ type: 'reaction', data });
    });

    socket.on('permissions-updated', (data) => {
        broadcastToTabs({ type: 'permissions-updated', data });
    });

    socket.on('typing', (data) => {
        broadcastToTabs({ type: 'typing', data });
    });

    socket.on('user-kicked', (data) => {
        broadcastToTabs({ type: 'user-kicked', data });
    });

    socket.on('kicked', () => {
        broadcastToTabs({ type: 'kicked' });
    });

    socket.on('room-locked', (data) => {
        broadcastToTabs({ type: 'room-locked', data });
    });

    // WebRTC signaling
    socket.on('voice-offer', async (data) => {
        console.log('[WatchParty BG] Received offer from', data.from);
        await handleVoiceOffer(data);
    });

    socket.on('voice-answer', async (data) => {
        console.log('[WatchParty BG] Received answer from', data.from);
        const pc = peerConnections.get(data.from);
        if (pc) {
            await pc.setRemoteDescription(new RTCSessionDescription(data.answer));
        }
    });

    socket.on('voice-ice-candidate', async (data) => {
        const pc = peerConnections.get(data.from);
        if (pc && data.candidate) {
            await pc.addIceCandidate(new RTCIceCandidate(data.candidate));
        }
    });

    socket.on('voice-user-joined', (data) => {
        console.log('[WatchParty BG] Voice user joined:', data.username);
        if (localStream) {
            initiateCall(data.socketId, data.username);
        }
        broadcastToTabs({ type: 'voice-user-joined', data });
    });

    socket.on('voice-user-left', (data) => {
        console.log('[WatchParty BG] Voice user left:', data.username);
        const pc = peerConnections.get(data.socketId);
        if (pc) {
            pc.close();
            peerConnections.delete(data.socketId);
        }
        broadcastToTabs({ type: 'voice-user-left', data });
    });

    socket.on('disconnect', () => {
        broadcastToTabs({ type: 'disconnected' });
        // Don't clear storage on random disconnect, only on manual disconnect
    });
}

// Restore connection on startup
chrome.storage.local.get(['connectionState'], (result) => {
    if (result.connectionState) {
        console.log('[WatchParty BG] Restoring connection from storage...');
        const { roomCode, username: savedName, isHost: savedIsHost, hostUrl: savedUrl } = result.connectionState;
        connect(roomCode, savedName, savedIsHost, savedUrl).catch(console.error);
    }
});

// Create peer connection
function createPeerConnection(remoteId, remoteName) {
    const pc = new RTCPeerConnection(iceServers);

    pc.onicecandidate = (event) => {
        if (event.candidate) {
            socket.emit('voice-ice-candidate', {
                roomCode: currentRoom,
                to: remoteId,
                candidate: event.candidate
            });
        }
    };

    pc.ontrack = (event) => {
        console.log('[WatchParty BG] Received remote track');
        broadcastToTabs({
            type: 'voice-stream',
            data: { username: remoteName, hasStream: true }
        });
    };

    pc.onconnectionstatechange = () => {
        console.log('[WatchParty BG] Connection state:', pc.connectionState);
        if (pc.connectionState === 'connected') {
            broadcastToTabs({ type: 'voice-connected', data: { username: remoteName } });
        }
    };

    // Add local tracks
    if (localStream) {
        localStream.getTracks().forEach(track => {
            pc.addTrack(track, localStream);
        });
    }

    peerConnections.set(remoteId, pc);
    return pc;
}

// Initiate call to new user
async function initiateCall(remoteId, remoteName) {
    const pc = createPeerConnection(remoteId, remoteName);

    try {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);

        socket.emit('voice-offer', {
            roomCode: currentRoom,
            to: remoteId,
            offer: offer,
            from: socket.id,
            username: username
        });
    } catch (error) {
        console.error('[WatchParty BG] Error creating offer:', error);
    }
}

// Handle incoming offer
async function handleVoiceOffer(data) {
    const pc = createPeerConnection(data.from, data.username);

    try {
        await pc.setRemoteDescription(new RTCSessionDescription(data.offer));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);

        socket.emit('voice-answer', {
            roomCode: currentRoom,
            to: data.from,
            answer: answer,
            from: socket.id
        });
    } catch (error) {
        console.error('[WatchParty BG] Error handling offer:', error);
    }
}

// Start voice chat
async function startVoice() {
    try {
        // Request microphone access
        localStream = await navigator.mediaDevices.getUserMedia({
            audio: { echoCancellation: true, noiseSuppression: true },
            video: false
        });

        // Notify server we're joining voice
        socket.emit('voice-join', { roomCode: currentRoom, username });

        broadcastToTabs({ type: 'voice-started', data: { username } });
        return { success: true };
    } catch (error) {
        console.error('[WatchParty BG] Microphone error:', error);
        return { success: false, error: error.message };
    }
}

// Stop voice chat
function stopVoice() {
    if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
        localStream = null;
    }

    peerConnections.forEach(pc => pc.close());
    peerConnections.clear();

    socket.emit('voice-leave', { roomCode: currentRoom, username });
    broadcastToTabs({ type: 'voice-stopped' });
}

// Toggle mute
function toggleMute(muted) {
    if (localStream) {
        localStream.getAudioTracks().forEach(track => {
            track.enabled = !muted;
        });
        socket.emit('voice-mute', { roomCode: currentRoom, username, muted });
        broadcastToTabs({ type: 'voice-mute-changed', data: { muted } });
    }
}

// Send playback update
function sendPlayback(action, currentTime) {
    if (socket && socket.connected) {
        socket.emit('playback-update', {
            roomCode: currentRoom,
            action,
            currentTime,
            userId: socket.id
        });
    }
}

// Send chat message
function sendChat(message) {
    if (socket && socket.connected && message) {
        socket.emit('chat-message', {
            roomCode: currentRoom,
            username,
            message,
            timestamp: Date.now()
        });
    }
}

// Send reaction
function sendReaction(emoji) {
    if (socket && socket.connected) {
        socket.emit('reaction', {
            roomCode: currentRoom,
            username,
            emoji
        });
    }
}

// Send typing indicator
function sendTyping() {
    if (socket && socket.connected) {
        socket.emit('typing', {
            roomCode: currentRoom,
            username
        });
    }
}

// Broadcast to all tabs
function broadcastToTabs(message) {
    chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
            chrome.tabs.sendMessage(tab.id, message).catch(() => { });
        });
    });
}

// Listen for messages
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'connect') {
        connect(msg.roomCode, msg.username, msg.isHost || false, msg.hostUrl || null)
            .then(() => sendResponse({ success: true }))
            .catch((err) => sendResponse({ success: false, error: err.message }));
        return true; // Keep message channel open for async response
    } else if (msg.action === 'disconnect') {
        if (socket) {
            socket.disconnect();
            socket = null;
        }
        currentRoom = null;
        isHost = false; // Reset host status
        chrome.storage.local.remove(['connectionState']); // Clear persistence
        sendResponse({ success: true });
    } else if (msg.action === 'sendPlayback') {
        sendPlayback(msg.playbackAction, msg.currentTime);
        sendResponse({ success: true });
    } else if (msg.action === 'sendChat') {
        sendChat(msg.message);
        sendResponse({ success: true });
    } else if (msg.action === 'sendReaction') {
        sendReaction(msg.emoji);
        sendResponse({ success: true });
    } else if (msg.action === 'sendTyping') {
        sendTyping();
        sendResponse({ success: true });
    } else if (msg.action === 'updatePermissions') {
        if (socket && socket.connected) {
            socket.emit('update-permissions', {
                roomCode: currentRoom,
                guestControls: msg.guestControls
            });
        }
        sendResponse({ success: true });
    } else if (msg.action === 'kickUser') {
        if (socket && socket.connected) {
            socket.emit('kick-user', {
                roomCode: currentRoom,
                targetUsername: msg.username
            });
        }
        sendResponse({ success: true });
    } else if (msg.action === 'lockRoom') {
        if (socket && socket.connected) {
            socket.emit('lock-room', {
                roomCode: currentRoom,
                locked: msg.locked
            });
        }
        sendResponse({ success: true });
    } else if (msg.action === 'startVoice') {
        startVoice().then(sendResponse);
        return true; // async response
    } else if (msg.action === 'stopVoice') {
        stopVoice();
        sendResponse({ success: true });
    } else if (msg.action === 'toggleMute') {
        toggleMute(msg.muted);
        sendResponse({ success: true });
    } else if (msg.action === 'getStatus') {
        sendResponse({
            connected: socket?.connected || false,
            room: currentRoom,
            username,
            isHost,
            voiceActive: !!localStream
        });
    }
    return true;
});

console.log('[WatchParty BG] Ready with voice support');
