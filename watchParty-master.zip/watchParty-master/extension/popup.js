// WatchParty Popup - Professional Flow with Supabase Auth

document.addEventListener('DOMContentLoaded', () => {
    // Config
    const SUPABASE_URL = 'https://hlhczpepjybikyetwxiv.supabase.co';
    const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhsaGN6cGVwanliaWt5ZXR3eGl2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjkyNDUyMjgsImV4cCI6MjA4NDgyMTIyOH0.SQ5ZOqoBFCFQe-IC051lunRiAZkaeT3dmFWCdcW8lQ8';

    // Initialize Supabase
    const { createClient } = window.supabase;
    const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

    // Constants
    const STORAGE_KEY = 'wp_auth_session';

    // Elements
    const steps = {
        auth: document.getElementById('step-auth'),
        menu: document.getElementById('step-menu'),
        host: document.getElementById('step-host'),
        join: document.getElementById('step-join'),
        connected: document.getElementById('step-connected')
    };

    // Auth Elements
    const tabs = document.querySelectorAll('.tab');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const loginEmail = document.getElementById('login-email');
    const loginPass = document.getElementById('login-password');
    const loginBtn = document.getElementById('login-btn');
    const loginError = document.getElementById('login-error');

    const regUsername = document.getElementById('register-username');
    const regEmail = document.getElementById('register-email');
    const regPass = document.getElementById('register-password');
    const regBtn = document.getElementById('register-btn');
    const regError = document.getElementById('register-error');
    const regSuccess = document.getElementById('register-success');

    // Menu Elements
    const userAvatar = document.getElementById('user-avatar');
    const userName = document.getElementById('user-name');
    const userEmail = document.getElementById('user-email');
    const logoutBtn = document.getElementById('logout-btn');
    const hostBtn = document.getElementById('hostBtn');
    const joinBtn = document.getElementById('joinBtn');

    // Common Elements
    const backFromHost = document.getElementById('backFromHost');
    const backFromJoin = document.getElementById('backFromJoin');
    const generatedCode = document.getElementById('generatedCode');
    const currentUrlEl = document.getElementById('currentUrl');
    const copyCodeBtn = document.getElementById('copyCodeBtn');
    const roomCodeInput = document.getElementById('roomCodeInput');
    const connectBtn = document.getElementById('connectBtn');
    const joinError = document.getElementById('joinError');
    const connectedRoomCode = document.getElementById('connectedRoomCode');
    const connectedInfo = document.getElementById('connectedInfo');
    const leaveBtn = document.getElementById('leaveBtn');
    const hostStatus = document.getElementById('hostStatus');
    const hostControls = document.getElementById('hostControls');
    const guestControlToggle = document.getElementById('guestControlToggle');

    let currentUser = null;
    let roomCode = '';
    let isHost = false;

    // Initialize
    checkSession();

    // functions
    function showStep(stepName) {
        Object.values(steps).forEach(step => step.classList.remove('active'));
        steps[stepName].classList.add('active');
    }

    function showLoading(btn, text) {
        const originalText = btn.innerHTML;
        btn.innerHTML = `<div class="spinner"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" class="spinner" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg></div> ${text}`;
        btn.disabled = true;
        return () => {
            btn.innerHTML = originalText;
            btn.disabled = false;
        };
    }

    // --- Auth Logic ---

    async function checkSession() {
        // Check background status first (Priority)
        const status = await new Promise(resolve => {
            chrome.runtime.sendMessage({ action: 'getStatus' }, response => resolve(response));
        });

        if (status && status.connected) {
            currentUser = { user_metadata: { username: status.username } }; // Minimal user obj
            roomCode = status.room;
            connectedInfo.textContent = `Watching as ${status.username}`;
            connectedRoomCode.textContent = roomCode;

            // Also fetch full user session if possible for Avatar/Menu
            chrome.storage.local.get(['session'], async (result) => {
                if (result.session) {
                    const { data: { user } } = await supabase.auth.getUser(result.session.access_token);
                    if (user) currentUser = user;
                }
            });

            showStep('connected');
            if (status.isHost) {
                hostControls.style.display = 'block';
                isHost = true;
            }
            return;
        }

        // Not connected? Check auth session
        chrome.storage.local.get(['session'], async (result) => {
            if (result.session) {
                const { data: { user }, error } = await supabase.auth.getUser(result.session.access_token);
                if (user && !error) {
                    handleLoginSuccess(user);
                } else {
                    showStep('auth');
                }
            } else {
                showStep('auth');
            }
        });
    }

    async function handleLoginSuccess(user) {
        currentUser = user;
        const meta = user.user_metadata || {};
        const name = meta.username || user.email.split('@')[0];

        // Update UI
        userName.textContent = name;
        userEmail.textContent = user.email;
        userAvatar.textContent = name.charAt(0).toUpperCase();

        // Save session
        const { data: { session } } = await supabase.auth.getSession();
        if (session) {
            chrome.storage.local.set({ session, username: name });
        }

        showStep('menu');
    }

    // Tabs
    tabs.forEach(tab => {
        tab.onclick = () => {
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            if (tab.dataset.tab === 'login') {
                loginForm.style.display = 'block';
                registerForm.style.display = 'none';
            } else {
                loginForm.style.display = 'none';
                registerForm.style.display = 'block';
            }
        };
    });

    // Login
    loginBtn.onclick = async () => {
        const email = loginEmail.value.trim();
        const password = loginPass.value.trim();

        if (!email || !password) {
            loginError.textContent = 'Please enter email and password';
            return;
        }

        const resetBtn = showLoading(loginBtn, 'Signing in...');
        loginError.textContent = '';

        try {
            const { data, error } = await supabase.auth.signInWithPassword({ email, password });
            if (error) throw error;
            await handleLoginSuccess(data.user);
        } catch (err) {
            loginError.textContent = err.message;
        } finally {
            resetBtn();
        }
    };

    // Register
    regBtn.onclick = async () => {
        const username = regUsername.value.trim();
        const email = regEmail.value.trim();
        const password = regPass.value.trim();

        if (!username || !email || !password) {
            regError.textContent = 'Please fill all fields';
            return;
        }
        if (password.length < 6) {
            regError.textContent = 'Password must be at least 6 characters';
            return;
        }

        const resetBtn = showLoading(regBtn, 'Creating account...');
        regError.textContent = '';
        regSuccess.textContent = '';

        try {
            const { data, error } = await supabase.auth.signUp({
                email,
                password,
                options: {
                    data: { username }
                }
            });
            if (error) throw error;

            // Also create record in public.users table if needed via API, 
            // but usually Supabase trigger handles this or we just use metadata

            if (data.session) {
                regSuccess.textContent = 'Account created! Logging you in...';
                setTimeout(() => handleLoginSuccess(data.user), 1000);
            } else if (data.user) {
                // User created but no session -> Email confirmation required
                regSuccess.textContent = 'Account created! Please check your email to confirm.';
                resetBtn();
            }
        } catch (err) {
            regError.textContent = err.message;
        } finally {
            if (!regSuccess.textContent.includes('Please check')) {
                resetBtn();
            }
        }
    };

    // Logout
    logoutBtn.onclick = async () => {
        await supabase.auth.signOut();
        chrome.storage.local.remove(['session', 'username']);
        currentUser = null;
        showStep('auth');
    };

    // --- WatchParty Logic ---

    function generateRoomCode() {
        const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        let code = '';
        for (let i = 0; i < 6; i++) {
            code += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return code;
    }

    // Host
    hostBtn.onclick = () => {
        isHost = true;
        roomCode = generateRoomCode();
        generatedCode.textContent = roomCode;

        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const currentUrl = tabs[0].url;
            currentUrlEl.innerHTML = `<strong>Sharing:</strong> ${currentUrl.length > 40 ? currentUrl.substring(0, 40) + '...' : currentUrl}`;

            // Connect
            const username = currentUser.user_metadata.username || 'User';
            chrome.runtime.sendMessage({
                action: 'connect',
                roomCode,
                username,
                isHost: true,
                hostUrl: currentUrl
            });

            hostControls.style.display = 'block';
            showStep('host');
        });
    };

    // Join Flow
    joinBtn.onclick = () => showStep('join');
    backFromHost.onclick = () => { chrome.runtime.sendMessage({ action: 'disconnect' }); showStep('menu'); };
    backFromJoin.onclick = () => showStep('menu');

    // Host Controls Toggle
    if (guestControlToggle) {
        guestControlToggle.onchange = (e) => {
            const allowed = e.target.checked;
            chrome.runtime.sendMessage({
                action: 'updatePermissions',
                guestControls: allowed
            });
        };
    }

    // Connect Button (Join)
    connectBtn.onclick = () => {
        roomCode = roomCodeInput.value.trim().toUpperCase();
        if (roomCode.length < 4) {
            joinError.textContent = 'Invalid room code';
            return;
        }

        const resetBtn = showLoading(connectBtn, 'Joining...');
        joinError.textContent = '';

        const username = currentUser.user_metadata.username || 'User';
        chrome.runtime.sendMessage({
            action: 'connect',
            roomCode,
            username,
            isHost: false
        }, (response) => {
            resetBtn();
            if (response && response.success) {
                connectedRoomCode.textContent = roomCode;
                connectedInfo.textContent = `Watching as ${username}`;
                showStep('connected');
            } else {
                joinError.textContent = response?.error || 'Failed to join room';
            }
        });
    };

    // Room Code Input
    roomCodeInput.onkeypress = (e) => { if (e.key === 'Enter') connectBtn.click(); };
    roomCodeInput.oninput = () => { joinError.textContent = ''; roomCodeInput.value = roomCodeInput.value.toUpperCase(); };

    // Leave
    leaveBtn.onclick = () => {
        chrome.runtime.sendMessage({ action: 'disconnect' });
        showStep('menu');
    };

    // Listen for events
    chrome.runtime.onMessage.addListener((msg) => {
        if (msg.type === 'user-joined' && isHost) {
            hostStatus.textContent = `${msg.data.username} joined!`;
            hostStatus.className = 'status connected';
        } else if (msg.type === 'redirect') {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                chrome.tabs.update(tabs[0].id, { url: msg.url });
            });
        } else if (msg.type === 'permissions-updated') {
            if (guestControlToggle) {
                guestControlToggle.checked = msg.data.guestControls;
            }
        }
    });

    // Copy code
    copyCodeBtn.onclick = () => {
        navigator.clipboard.writeText(roomCode);
        const original = copyCodeBtn.innerHTML;
        copyCodeBtn.innerHTML = 'Copied!';
        setTimeout(() => copyCodeBtn.innerHTML = original, 2000);
    };
});
